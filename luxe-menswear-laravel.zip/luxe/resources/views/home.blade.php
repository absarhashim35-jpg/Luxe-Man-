@extends('layouts.app')
@section('title', 'Luxe — Elegance, Tailored for You')

@section('content')

{{-- HERO --}}
<section class="hero" style="background-image: linear-gradient(180deg, rgba(17,17,17,0.6), rgba(17,17,17,0.35)), url('https://images.unsplash.com/photo-1617137968427-85924c800a22?w=1600&q=80');">
    <div class="container">
        <div class="hero-content">
            <span class="eyebrow" style="color:#C9A96E;">The 2026 Collection</span>
            <h1>Elegance, Tailored<br>for You</h1>
            <p>Discover a curated edit of suits, shirts and accessories crafted for the modern gentleman — precision tailoring, timeless materials, effortless refinement.</p>
            <div class="d-flex gap-3 flex-wrap">
                <a href="{{ route('shop.index') }}" class="btn-luxe" style="background:#C9A96E;border-color:#C9A96E;">Shop Collection</a>
                <a href="{{ route('shop.index', ['sort'=>'latest']) }}" class="btn-luxe-outline" style="border-color:#fff;color:#fff;">Explore New Arrivals</a>
            </div>
        </div>
    </div>
</section>

{{-- CATEGORIES --}}
<section class="py-5 my-5">
    <div class="container">
        <div class="section-title">
            <span class="eyebrow">Shop by Category</span>
            <h2>Curated Essentials</h2>
        </div>
        <div class="row g-4">
            @php
                $catImages = [
                    'suits' => 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=700&q=80',
                    'blazers' => 'https://images.unsplash.com/photo-1611312449408-fcece27cdbb7?w=700&q=80',
                    'formal-shirts' => 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=700&q=80',
                    'ties' => 'https://images.unsplash.com/photo-1589756823695-278bc923f962?w=700&q=80',
                    'formal-shoes' => 'https://images.unsplash.com/photo-1614252369475-531eba835eb1?w=700&q=80',
                    'accessories' => 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?w=700&q=80',
                ];
            @endphp
            @foreach($categories as $cat)
                <div class="col-lg-4 col-md-6">
                    <a href="{{ route('shop.index', ['category'=>$cat->slug]) }}" class="category-card">
                        <img src="{{ $cat->image ? image_url($cat->image) : ($catImages[$cat->slug] ?? 'https://images.unsplash.com/photo-1516257984-b1b4d707412e?w=700&q=80') }}" alt="{{ $cat->name }}">
                        <div class="overlay"><h5>{{ $cat->name }}</h5></div>
                    </a>
                </div>
            @endforeach
        </div>
    </div>
</section>

{{-- FEATURED --}}
<section class="py-5 bg-secondary-luxe">
    <div class="container py-4">
        <div class="section-title">
            <span class="eyebrow">Handpicked</span>
            <h2>Featured Products</h2>
        </div>
        <div class="row g-4">
            @foreach($featured as $product)
                <div class="col-lg-3 col-md-6">
                    <x-product-card :product="$product" />
                </div>
            @endforeach
        </div>
        <div class="text-center mt-5">
            <a href="{{ route('shop.index') }}" class="btn-luxe-outline">View All Products</a>
        </div>
    </div>
</section>

{{-- NEW ARRIVALS --}}
@if($newArrivals->count())
<section class="py-5 my-3">
    <div class="container">
        <div class="section-title">
            <span class="eyebrow">Just In</span>
            <h2>New Arrivals</h2>
        </div>
        <div class="row g-4">
            @foreach($newArrivals->take(4) as $product)
                <div class="col-lg-3 col-md-6">
                    <x-product-card :product="$product" />
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif

{{-- PROMO BANNER --}}
<section class="container my-5">
    <div class="promo-banner" style="background-image: linear-gradient(180deg, rgba(17,17,17,0.55), rgba(17,17,17,0.75)), url('https://images.unsplash.com/photo-1550246140-29f40b909e5a?w=1600&q=80');">
        <span class="eyebrow">Limited Time</span>
        <h2>Up to 30% Off Tailored Suits</h2>
        <p class="mb-4">Elevate your wardrobe with our signature tailoring collection.</p>
        <a href="{{ route('shop.index', ['category'=>'suits']) }}" class="btn-gold">Shop the Sale</a>
    </div>
</section>

{{-- BEST SELLERS --}}
@if($bestSellers->count())
<section class="py-5 bg-secondary-luxe">
    <div class="container py-4">
        <div class="section-title">
            <span class="eyebrow">Customer Favorites</span>
            <h2>Best Sellers</h2>
        </div>
        <div class="row g-4">
            @foreach($bestSellers->take(4) as $product)
                <div class="col-lg-3 col-md-6">
                    <x-product-card :product="$product" />
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif

{{-- WHY CHOOSE US --}}
<section class="py-5 my-5 why-us">
    <div class="container">
        <div class="row g-4 text-center">
            <div class="col-md-3 col-6">
                <div class="icon-box"><i class="bi bi-gem"></i></div>
                <h6>Premium Quality</h6>
                <p class="small text-muted-luxe">Finest fabrics, expert craftsmanship.</p>
            </div>
            <div class="col-md-3 col-6">
                <div class="icon-box"><i class="bi bi-shield-check"></i></div>
                <h6>Secure Payment</h6>
                <p class="small text-muted-luxe">100% protected checkout.</p>
            </div>
            <div class="col-md-3 col-6">
                <div class="icon-box"><i class="bi bi-truck"></i></div>
                <h6>Fast Delivery</h6>
                <p class="small text-muted-luxe">Nationwide express shipping.</p>
            </div>
            <div class="col-md-3 col-6">
                <div class="icon-box"><i class="bi bi-arrow-repeat"></i></div>
                <h6>Easy Returns</h6>
                <p class="small text-muted-luxe">30-day hassle-free returns.</p>
            </div>
        </div>
    </div>
</section>

{{-- REVIEWS --}}
@if($reviews->count())
<section class="py-5 bg-secondary-luxe">
    <div class="container py-4">
        <div class="section-title">
            <span class="eyebrow">Testimonials</span>
            <h2>What Our Customers Say</h2>
        </div>
        <div class="row g-4">
            @foreach($reviews as $review)
                <div class="col-md-4">
                    <div class="review-card">
                        <div class="stars mb-2">
                            @for($i=1;$i<=5;$i++)<i class="bi bi-star{{ $i <= $review->rating ? '-fill' : '' }}"></i>@endfor
                        </div>
                        <p class="small">&ldquo;{{ \Illuminate\Support\Str::limit($review->comment, 140) }}&rdquo;</p>
                        <div class="fw-semibold small mt-3">{{ $review->user->name ?? 'Verified Buyer' }}</div>
                        <div class="text-muted-luxe small">{{ $review->product->name ?? '' }}</div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
</section>
@endif

{{-- NEWSLETTER --}}
<section class="newsletter">
    <div class="container">
        <span class="eyebrow">Stay in Style</span>
        <h2 class="mb-3">Join the Luxe Circle</h2>
        <p class="text-muted-luxe mb-4">Subscribe for exclusive previews, private sales, and styling notes.</p>
        <form class="d-flex justify-content-center gap-2 flex-wrap">
            <input type="email" class="form-control" placeholder="Enter your email" style="max-width:320px;border-radius:2px;">
            <button class="btn-luxe">Subscribe</button>
        </form>
    </div>
</section>

@endsection
