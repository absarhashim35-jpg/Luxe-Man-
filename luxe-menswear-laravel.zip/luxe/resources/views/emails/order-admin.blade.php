<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>New Order</title></head>
<body style="margin:0;padding:0;background:#f5f5f5;font-family:Arial,Helvetica,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;padding:30px 0;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:4px;overflow:hidden;">
    <tr><td style="background:#111111;padding:30px 40px;text-align:center;">
        <span style="color:#ffffff;font-size:24px;letter-spacing:3px;font-weight:bold;">LUXE<span style="color:#C9A96E;">.</span></span>
    </td></tr>
    <tr><td style="padding:30px 40px 10px;">
        <p style="color:#C9A96E;letter-spacing:2px;text-transform:uppercase;font-size:12px;margin:0 0 6px;">New Order Received</p>
        <h2 style="color:#111111;margin:0 0 20px;">Order {{ $order->order_number }}</h2>
    </td></tr>
    <tr><td style="padding:0 40px;">
        <table width="100%" style="border-collapse:collapse;font-size:14px;color:#171717;">
            <tr><td style="padding:6px 0;color:#777;">Customer:</td><td><strong>{{ $order->full_name }}</strong></td></tr>
            <tr><td style="padding:6px 0;color:#777;">Email:</td><td>{{ $order->email }}</td></tr>
            <tr><td style="padding:6px 0;color:#777;">Phone:</td><td>{{ $order->phone }}</td></tr>
            <tr><td style="padding:6px 0;color:#777;">Shipping Address:</td><td>{{ $order->address_line }}, {{ $order->city }}, {{ $order->state }} {{ $order->postal_code }}, {{ $order->country }}</td></tr>
            <tr><td style="padding:6px 0;color:#777;">Payment Method:</td><td>{{ ucfirst(str_replace('_',' ',$order->payment_method)) }}</td></tr>
            <tr><td style="padding:6px 0;color:#777;">Order Date:</td><td>{{ $order->created_at->format('M d, Y g:i A') }}</td></tr>
        </table>
    </td></tr>
    <tr><td style="padding:24px 40px 10px;">
        <table width="100%" style="border-collapse:collapse;font-size:13px;">
            <tr style="background:#F5F5F5;text-transform:uppercase;letter-spacing:1px;">
                <td style="padding:10px;">Product</td><td style="padding:10px;">Qty</td><td style="padding:10px;">Price</td><td style="padding:10px;">Total</td>
            </tr>
            @foreach($order->items as $item)
            <tr style="border-bottom:1px solid #ECECEC;">
                <td style="padding:10px;">
                    @if($item->product_image)<img src="{{ image_url($item->product_image) }}" width="40" style="vertical-align:middle;margin-right:8px;border-radius:2px;">@endif
                    {{ $item->product_name }} @if($item->size) ({{ $item->size }}@if($item->color), {{ $item->color }}@endif) @endif
                </td>
                <td style="padding:10px;">{{ $item->quantity }}</td>
                <td style="padding:10px;">${{ number_format($item->price,2) }}</td>
                <td style="padding:10px;">${{ number_format($item->line_total,2) }}</td>
            </tr>
            @endforeach
        </table>
    </td></tr>
    <tr><td style="padding:10px 40px 30px;text-align:right;font-size:14px;color:#171717;">
        <p style="margin:4px 0;">Subtotal: ${{ number_format($order->subtotal,2) }}</p>
        <p style="margin:4px 0;">Shipping: ${{ number_format($order->shipping_cost,2) }}</p>
        <p style="margin:4px 0;">Discount: -${{ number_format($order->discount,2) }}</p>
        <p style="margin:10px 0 0;font-size:18px;color:#111;"><strong>Grand Total: ${{ number_format($order->grand_total,2) }}</strong></p>
    </td></tr>
    <tr><td style="background:#111;padding:18px 40px;text-align:center;">
        <span style="color:#999;font-size:12px;">Luxe Admin Notification — do not reply to this email</span>
    </td></tr>
</table>
</td></tr>
</table>
</body>
</html>
