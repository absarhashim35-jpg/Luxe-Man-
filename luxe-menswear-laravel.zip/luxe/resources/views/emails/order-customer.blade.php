<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Order Confirmation</title></head>
<body style="margin:0;padding:0;background:#f5f5f5;font-family:Arial,Helvetica,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;padding:30px 0;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:4px;overflow:hidden;">
    <tr><td style="background:#111111;padding:36px 40px;text-align:center;">
        <span style="color:#ffffff;font-size:26px;letter-spacing:3px;font-weight:bold;">LUXE<span style="color:#C9A96E;">.</span></span>
    </td></tr>
    <tr><td style="padding:36px 40px 10px;text-align:center;">
        <p style="color:#C9A96E;letter-spacing:2px;text-transform:uppercase;font-size:12px;margin:0 0 10px;">Thank You for Your Order</p>
        <h2 style="color:#111111;margin:0 0 10px;">Hi {{ $order->full_name }},</h2>
        <p style="color:#777;font-size:14px;">Your order has been received and is being prepared with care.</p>
    </td></tr>
    <tr><td style="padding:10px 40px;">
        <table width="100%" style="border-collapse:collapse;font-size:14px;color:#171717;background:#F5F5F5;border-radius:4px;">
            <tr><td style="padding:16px 20px;" colspan="2"><strong>Order Number:</strong> {{ $order->order_number }}</td></tr>
        </table>
    </td></tr>
    <tr><td style="padding:20px 40px 10px;">
        <table width="100%" style="border-collapse:collapse;font-size:13px;">
            <tr style="background:#F5F5F5;text-transform:uppercase;letter-spacing:1px;">
                <td style="padding:10px;">Product</td><td style="padding:10px;">Qty</td><td style="padding:10px;">Total</td>
            </tr>
            @foreach($order->items as $item)
            <tr style="border-bottom:1px solid #ECECEC;">
                <td style="padding:10px;">
                    @if($item->product_image)<img src="{{ image_url($item->product_image) }}" width="40" style="vertical-align:middle;margin-right:8px;border-radius:2px;">@endif
                    {{ $item->product_name }} @if($item->size) ({{ $item->size }}@if($item->color), {{ $item->color }}@endif) @endif
                </td>
                <td style="padding:10px;">{{ $item->quantity }}</td>
                <td style="padding:10px;">${{ number_format($item->line_total,2) }}</td>
            </tr>
            @endforeach
        </table>
    </td></tr>
    <tr><td style="padding:10px 40px 20px;text-align:right;">
        <p style="margin:14px 0 0;font-size:20px;color:#111;"><strong>Total: ${{ number_format($order->grand_total,2) }}</strong></p>
    </td></tr>
    <tr><td style="padding:0 40px 30px;">
        <p style="font-size:13px;color:#777;margin:0 0 4px;"><strong style="color:#171717;">Shipping Address:</strong><br>{{ $order->address_line }}, {{ $order->city }}, {{ $order->state }} {{ $order->postal_code }}, {{ $order->country }}</p>
        <p style="font-size:13px;color:#777;margin:12px 0 0;"><strong style="color:#171717;">Payment Method:</strong> {{ ucfirst(str_replace('_',' ',$order->payment_method)) }}</p>
        <p style="font-size:13px;color:#777;margin:12px 0 0;"><strong style="color:#171717;">Order Status:</strong> {{ \App\Models\Order::STATUSES[$order->status] }}</p>
    </td></tr>
    <tr><td style="text-align:center;padding:0 40px 36px;">
        <a href="{{ route('order.track.form') }}" style="background:#111;color:#fff;text-decoration:none;padding:14px 32px;font-size:13px;letter-spacing:2px;text-transform:uppercase;border-radius:2px;display:inline-block;">Track Your Order</a>
    </td></tr>
    <tr><td style="background:#111;padding:20px 40px;text-align:center;">
        <span style="color:#999;font-size:12px;">&copy; {{ date('Y') }} Luxe — Elegance, Tailored for You</span>
    </td></tr>
</table>
</td></tr>
</table>
</body>
</html>
