@extends('layouts.app')
@section('title', 'My Orders — Luxe')
@section('content')
<div class="container py-5">
    <div class="row g-4">
        <div class="col-lg-3">@include('account.sidebar')</div>
        <div class="col-lg-9">
            <h4 class="mb-4">My Orders</h4>
            <div class="table-responsive">
                <table class="table table-luxe align-middle">
                    <thead><tr><th>Order #</th><th>Date</th><th>Items</th><th>Total</th><th>Status</th><th></th></tr></thead>
                    <tbody>
                        @forelse($orders as $order)
                            <tr>
                                <td>{{ $order->order_number }}</td>
                                <td>{{ $order->created_at->format('M d, Y') }}</td>
                                <td>{{ $order->items()->count() }}</td>
                                <td>${{ number_format($order->grand_total, 2) }}</td>
                                <td><span class="badge bg-dark">{{ \App\Models\Order::STATUSES[$order->status] }}</span></td>
                                <td><a href="{{ route('account.order.show', $order) }}" class="small">View Details</a></td>
                            </tr>
                        @empty
                            <tr><td colspan="6" class="text-center text-muted-luxe py-4">You haven't placed any orders yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            {{ $orders->links() }}
        </div>
    </div>
</div>
@endsection
