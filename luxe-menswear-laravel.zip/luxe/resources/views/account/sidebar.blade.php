<div class="filter-box mb-4">
    <div class="text-center mb-3">
        <div class="mx-auto mb-2" style="width:60px;height:60px;border-radius:50%;background:#111;color:#C9A96E;display:flex;align-items:center;justify-content:center;font-size:1.4rem;">
            {{ strtoupper(substr(auth()->user()->name,0,1)) }}
        </div>
        <div class="fw-semibold">{{ auth()->user()->name }}</div>
        <div class="small text-muted-luxe">{{ auth()->user()->email }}</div>
    </div>
    <hr>
    <a href="{{ route('account.dashboard') }}" class="d-block py-2 small">Dashboard</a>
    <a href="{{ route('account.profile') }}" class="d-block py-2 small">Edit Profile</a>
    <a href="{{ route('account.orders') }}" class="d-block py-2 small">My Orders</a>
    <a href="{{ route('account.wishlist') }}" class="d-block py-2 small">Wishlist</a>
    <a href="{{ route('account.addresses') }}" class="d-block py-2 small">Saved Addresses</a>
    <form action="{{ route('logout') }}" method="POST" class="mt-2">
        @csrf
        <button class="btn btn-link p-0 small text-danger">Logout</button>
    </form>
</div>
