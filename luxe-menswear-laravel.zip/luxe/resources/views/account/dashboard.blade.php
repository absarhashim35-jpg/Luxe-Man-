@extends('layouts.app')
@section('title', 'My Account — Luxe')
@section('content')
<div class="container py-5">
    <div class="row g-4">
        <div class="col-lg-3">@include('account.sidebar')</div>
        <div class="col-lg-9">
            <h4 class="mb-4">Welcome back, {{ $user->name }}</h4>
            <div class="row g-3 mb-4">
                <div class="col-md-4"><div class="admin-stat-card"><small class="text-muted-luxe">Total Orders</small><h3>{{ $user->orders()->count() }}</h3></div></div>
                <div class="col-md-4"><div class="admin-stat-card"><small class="text-muted-luxe">Wishlist Items</small><h3>{{ optional($user->wishlist)->items->count() ?? 0 }}</h3></div></div>
                <div class="col-md-4"><div class="admin-stat-card"><small class="text-muted-luxe">Saved Addresses</small><h3>{{ $user->addresses->count() }}</h3></div></div>
            </div>

            <h5 class="mb-3">Recent Orders</h5>
            <div class="table-responsive">
                <table class="table table-luxe align-middle">
                    <thead><tr><th>Order #</th><th>Date</th><th>Total</th><th>Status</th><th></th></tr></thead>
                    <tbody>
                        @forelse($recentOrders as $order)
                            <tr>
                                <td>{{ $order->order_number }}</td>
                                <td>{{ $order->created_at->format('M d, Y') }}</td>
                                <td>${{ number_format($order->grand_total, 2) }}</td>
                                <td><span class="badge bg-dark">{{ \App\Models\Order::STATUSES[$order->status] }}</span></td>
                                <td><a href="{{ route('account.order.show', $order) }}" class="small">View</a></td>
                            </tr>
                        @empty
                            <tr><td colspan="5" class="text-muted-luxe text-center py-4">No orders yet.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
