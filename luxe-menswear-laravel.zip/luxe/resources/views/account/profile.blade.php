@extends('layouts.app')
@section('title', 'Edit Profile — Luxe')
@section('content')
<div class="container py-5">
    <div class="row g-4">
        <div class="col-lg-3">@include('account.sidebar')</div>
        <div class="col-lg-9">
            <h4 class="mb-4">Edit Profile</h4>
            <form action="{{ route('account.profile.update') }}" method="POST" class="filter-box mb-4">
                @csrf @method('PUT')
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="small">Full Name</label>
                        <input type="text" name="name" class="form-control" value="{{ old('name', $user->name) }}">
                    </div>
                    <div class="col-md-6">
                        <label class="small">Email</label>
                        <input type="email" name="email" class="form-control" value="{{ old('email', $user->email) }}">
                    </div>
                    <div class="col-md-6">
                        <label class="small">Phone</label>
                        <input type="text" name="phone" class="form-control" value="{{ old('phone', $user->phone) }}">
                    </div>
                </div>
                <button class="btn-luxe mt-4">Save Changes</button>
            </form>

            <h5 class="mb-3">Change Password</h5>
            <form action="{{ route('account.password.update') }}" method="POST" class="filter-box">
                @csrf @method('PUT')
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="small">Current Password</label>
                        <input type="password" name="current_password" class="form-control @error('current_password') is-invalid @enderror">
                        @error('current_password')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-4">
                        <label class="small">New Password</label>
                        <input type="password" name="password" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label class="small">Confirm New Password</label>
                        <input type="password" name="password_confirmation" class="form-control">
                    </div>
                </div>
                <button class="btn-luxe mt-4">Update Password</button>
            </form>
        </div>
    </div>
</div>
@endsection
