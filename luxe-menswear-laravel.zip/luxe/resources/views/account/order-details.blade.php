@extends('layouts.app')
@section('title', 'Order ' . $order->order_number . ' — Luxe')
@section('content')
<div class="container py-5">
    <div class="row g-4">
        <div class="col-lg-3">@include('account.sidebar')</div>
        <div class="col-lg-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4>Order {{ $order->order_number }}</h4>
                <span class="badge bg-dark">{{ \App\Models\Order::STATUSES[$order->status] }}</span>
            </div>

            <div class="filter-box mb-4">
                @foreach($order->items as $item)
                    <div class="d-flex justify-content-between border-bottom py-2 small">
                        <span>{{ $item->product_name }} @if($item->size)({{ $item->size }})@endif &times; {{ $item->quantity }}</span>
                        <span>${{ number_format($item->line_total, 2) }}</span>
                    </div>
                @endforeach
                <div class="d-flex justify-content-between pt-3 fw-bold"><span>Grand Total</span><span>${{ number_format($order->grand_total, 2) }}</span></div>
            </div>

            <div class="row g-4">
                <div class="col-md-6">
                    <h6>Shipping Address</h6>
                    <p class="small text-muted-luxe">{{ $order->full_name }}<br>{{ $order->address_line }}<br>{{ $order->city }}, {{ $order->state }} {{ $order->postal_code }}<br>{{ $order->country }}<br>{{ $order->phone }}</p>
                </div>
                <div class="col-md-6">
                    <h6>Payment</h6>
                    <p class="small text-muted-luxe">Method: {{ ucfirst(str_replace('_',' ',$order->payment_method)) }}<br>Status: {{ ucfirst($order->payment_status) }}</p>
                    <a href="{{ route('order.track.form') }}" class="btn-luxe-outline btn-sm">Track This Order</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
