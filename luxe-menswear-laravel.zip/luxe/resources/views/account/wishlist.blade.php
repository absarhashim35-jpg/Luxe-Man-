@extends('layouts.app')
@section('title', 'My Wishlist — Luxe')
@section('content')
<div class="container py-5">
    <div class="row g-4">
        <div class="col-lg-3">@include('account.sidebar')</div>
        <div class="col-lg-9">
            <h4 class="mb-4">My Wishlist</h4>
            <div class="row g-4">
                @forelse($wishlist->items as $item)
                    <div class="col-lg-4 col-md-6">
                        <x-product-card :product="$item->product" />
                    </div>
                @empty
                    <p class="text-muted-luxe">Your wishlist is empty. <a href="{{ route('shop.index') }}" class="text-gold">Browse products</a>.</p>
                @endforelse
            </div>
        </div>
    </div>
</div>
@endsection
