@extends('layouts.app')
@section('title', 'Saved Addresses — Luxe')
@section('content')
<div class="container py-5">
    <div class="row g-4">
        <div class="col-lg-3">@include('account.sidebar')</div>
        <div class="col-lg-9">
            <h4 class="mb-4">Saved Addresses</h4>

            <div class="row g-3 mb-4">
                @forelse($addresses as $addr)
                    <div class="col-md-6">
                        <div class="filter-box">
                            <div class="d-flex justify-content-between">
                                <strong>{{ $addr->label }}</strong>
                                <form action="{{ route('account.addresses.delete', $addr) }}" method="POST">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-link btn-sm text-danger p-0">Remove</button>
                                </form>
                            </div>
                            <p class="small text-muted-luxe mb-0">{{ $addr->full_name }}<br>{{ $addr->address_line }}<br>{{ $addr->city }}, {{ $addr->state }} {{ $addr->postal_code }}<br>{{ $addr->country }}<br>{{ $addr->phone }}</p>
                        </div>
                    </div>
                @empty
                    <p class="text-muted-luxe">No saved addresses yet.</p>
                @endforelse
            </div>

            <h5 class="mb-3">Add New Address</h5>
            <form action="{{ route('account.addresses.store') }}" method="POST" class="filter-box">
                @csrf
                <div class="row g-3">
                    <div class="col-md-4"><label class="small">Label</label><input type="text" name="label" class="form-control" placeholder="Home / Office"></div>
                    <div class="col-md-4"><label class="small">Full Name</label><input type="text" name="full_name" class="form-control" required></div>
                    <div class="col-md-4"><label class="small">Phone</label><input type="text" name="phone" class="form-control" required></div>
                    <div class="col-12"><label class="small">Address</label><input type="text" name="address_line" class="form-control" required></div>
                    <div class="col-md-4"><label class="small">City</label><input type="text" name="city" class="form-control" required></div>
                    <div class="col-md-4"><label class="small">State</label><input type="text" name="state" class="form-control"></div>
                    <div class="col-md-4"><label class="small">Postal Code</label><input type="text" name="postal_code" class="form-control" required></div>
                    <div class="col-md-6"><label class="small">Country</label><input type="text" name="country" class="form-control" required></div>
                </div>
                <button class="btn-luxe mt-4">Save Address</button>
            </form>
        </div>
    </div>
</div>
@endsection
