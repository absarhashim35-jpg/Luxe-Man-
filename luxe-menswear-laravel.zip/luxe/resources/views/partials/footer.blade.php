<footer class="footer-luxe">
    <div class="container">
        <div class="row g-4">
            <div class="col-lg-4">
                <h5 class="text-white font-serif">LUXE<span class="text-gold">.</span></h5>
                <p class="small">Elegance, tailored for you. Premium menswear crafted for the modern gentleman — suits, shirts, shoes and accessories designed with timeless precision.</p>
                <div>
                    <a href="#" class="me-3"><i class="bi bi-instagram fs-5"></i></a>
                    <a href="#" class="me-3"><i class="bi bi-facebook fs-5"></i></a>
                    <a href="#"><i class="bi bi-twitter-x fs-5"></i></a>
                </div>
            </div>
            <div class="col-lg-2 col-6">
                <h6>Shop</h6>
                <ul class="list-unstyled small">
                    <li class="mb-2"><a href="{{ route('shop.index') }}">All Products</a></li>
                    <li class="mb-2"><a href="{{ route('shop.index', ['sort'=>'latest']) }}">New Arrivals</a></li>
                    <li class="mb-2"><a href="{{ route('shop.index', ['sort'=>'popular']) }}">Best Sellers</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-6">
                <h6>Support</h6>
                <ul class="list-unstyled small">
                    <li class="mb-2"><a href="{{ route('contact') }}">Contact Us</a></li>
                    <li class="mb-2"><a href="{{ route('order.track.form') }}">Track Order</a></li>
                    <li class="mb-2"><a href="{{ route('about') }}">About Us</a></li>
                </ul>
            </div>
            <div class="col-lg-4">
                <h6>Newsletter</h6>
                <p class="small">Subscribe for early access to new collections and private sales.</p>
                <form class="d-flex gap-2">
                    <input type="email" class="form-control form-control-sm" placeholder="Your email" style="border-radius:2px;">
                    <button class="btn btn-gold btn-sm">Join</button>
                </form>
            </div>
        </div>
        <hr class="my-4">
        <div class="d-flex justify-content-between flex-wrap small">
            <span>&copy; {{ date('Y') }} Luxe. All rights reserved.</span>
            <span>Crafted with precision — Black · White · Gold</span>
        </div>
    </div>
</footer>
