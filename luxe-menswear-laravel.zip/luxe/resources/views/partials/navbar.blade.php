@php
    $cartCount = 0;
    if (isset($cart)) { $cartCount = $cart->items->sum('quantity'); }
@endphp
<nav class="navbar navbar-expand-lg navbar-luxe sticky-top">
    <div class="container">
        <a class="navbar-brand brand" href="{{ route('home') }}">LUXE<span>.</span></a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navMain">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item"><a class="nav-link" href="{{ route('home') }}">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('shop.index') }}">Shop</a></li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">Categories</a>
                    <ul class="dropdown-menu">
                        @foreach(\App\Models\Category::active()->orderBy('sort_order')->get() as $cat)
                            <li><a class="dropdown-item" href="{{ route('shop.index', ['category' => $cat->slug]) }}">{{ $cat->name }}</a></li>
                        @endforeach
                    </ul>
                </li>
                <li class="nav-item"><a class="nav-link" href="{{ route('shop.index', ['sort' => 'latest']) }}">New Arrivals</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('about') }}">About</a></li>
                <li class="nav-item"><a class="nav-link" href="{{ route('contact') }}">Contact</a></li>
            </ul>

            <div class="d-flex align-items-center navbar-icons">
                <form action="{{ route('shop.index') }}" method="GET" class="d-none d-lg-flex align-items-center me-2">
                    <input type="search" name="q" class="form-control form-control-sm border-0 border-bottom" placeholder="Search..." style="width:140px;">
                </form>
                <a href="{{ route('shop.index') }}" class="d-lg-none"><i class="bi bi-search"></i></a>
                @auth
                    <a href="{{ route('account.wishlist') }}"><i class="bi bi-heart"></i></a>
                @else
                    <a href="{{ route('login') }}"><i class="bi bi-heart"></i></a>
                @endauth
                <a href="{{ route('cart.index') }}" class="position-relative">
                    <i class="bi bi-bag"></i>
                    <span class="badge-count" id="cart-count-badge">{{ $cartCount }}</span>
                </a>
                @auth
                    <div class="dropdown d-inline-block">
                        <a href="#" data-bs-toggle="dropdown"><i class="bi bi-person"></i></a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="{{ route('account.dashboard') }}">My Account</a></li>
                            <li><a class="dropdown-item" href="{{ route('account.orders') }}">My Orders</a></li>
                            @if(auth()->user()->is_admin)
                                <li><a class="dropdown-item" href="{{ route('admin.dashboard') }}">Admin Panel</a></li>
                            @endif
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form action="{{ route('logout') }}" method="POST">
                                    @csrf
                                    <button class="dropdown-item">Logout</button>
                                </form>
                            </li>
                        </ul>
                    </div>
                @else
                    <a href="{{ route('login') }}"><i class="bi bi-person"></i></a>
                @endauth
            </div>
        </div>
    </div>
</nav>
