@extends('layouts.admin')
@section('title', 'Settings — Luxe Admin')
@section('content')
<h3 class="mb-4">Store Settings</h3>
<form action="{{ route('admin.settings.update') }}" method="POST" class="admin-stat-card">
    @csrf @method('PUT')
    <div class="row g-3">
        <div class="col-md-6"><label class="small">Store Name</label><input type="text" name="store_name" class="form-control" value="{{ old('store_name', $settings['store_name'] ?? 'Luxe') }}"></div>
        <div class="col-md-6"><label class="small">Admin Email</label><input type="email" name="admin_email" class="form-control" value="{{ old('admin_email', $settings['admin_email'] ?? env('ADMIN_ORDER_EMAIL')) }}"></div>
        <div class="col-md-6"><label class="small">Store Phone</label><input type="text" name="store_phone" class="form-control" value="{{ old('store_phone', $settings['store_phone'] ?? '') }}"></div>
        <div class="col-md-6"><label class="small">Currency</label><input type="text" name="currency" class="form-control" value="{{ old('currency', $settings['currency'] ?? 'USD') }}"></div>
        <div class="col-12"><label class="small">Store Address</label><input type="text" name="store_address" class="form-control" value="{{ old('store_address', $settings['store_address'] ?? '') }}"></div>
        <div class="col-md-6"><label class="small">Flat Shipping Rate ($)</label><input type="number" step="0.01" name="flat_shipping_rate" class="form-control" value="{{ old('flat_shipping_rate', $settings['flat_shipping_rate'] ?? 15) }}"></div>
        <div class="col-md-6"><label class="small">Free Shipping Threshold ($)</label><input type="number" step="0.01" name="free_shipping_threshold" class="form-control" value="{{ old('free_shipping_threshold', $settings['free_shipping_threshold'] ?? 200) }}"></div>
    </div>
    <p class="small text-muted-luxe mt-3">SMTP / mail credentials are configured in your <code>.env</code> file (MAIL_HOST, MAIL_USERNAME, MAIL_PASSWORD, ADMIN_ORDER_EMAIL) for security.</p>
    <button class="btn-luxe mt-2">Save Settings</button>
</form>
@endsection
