@extends('layouts.admin')
@section('title', 'Reviews — Luxe Admin')
@section('content')
<h3 class="mb-4">Reviews</h3>
<div class="admin-stat-card">
    <table class="table table-luxe align-middle">
        <thead><tr><th>Product</th><th>Customer</th><th>Rating</th><th>Comment</th><th>Status</th><th></th></tr></thead>
        <tbody>
            @foreach($reviews as $r)
                <tr>
                    <td>{{ $r->product->name ?? '—' }}</td>
                    <td>{{ $r->user->name ?? '—' }}</td>
                    <td>{{ $r->rating }} ★</td>
                    <td class="small">{{ \Illuminate\Support\Str::limit($r->comment, 60) }}</td>
                    <td><span class="badge {{ $r->is_approved ? 'bg-success' : 'bg-secondary' }}">{{ $r->is_approved ? 'Approved' : 'Pending' }}</span></td>
                    <td class="text-nowrap">
                        @unless($r->is_approved)
                            <form action="{{ route('admin.reviews.approve', $r) }}" method="POST" class="d-inline">
                                @csrf @method('PATCH')
                                <button class="btn btn-link btn-sm p-0 me-2">Approve</button>
                            </form>
                        @endunless
                        <form action="{{ route('admin.reviews.destroy', $r) }}" method="POST" class="d-inline">
                            @csrf @method('DELETE')
                            <button class="btn btn-link btn-sm text-danger p-0">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    {{ $reviews->links() }}
</div>
@endsection
