@extends('layouts.admin')
@section('title', ($product->exists ? 'Edit' : 'Add') . ' Product — Luxe Admin')
@section('content')
<h3 class="mb-4">{{ $product->exists ? 'Edit' : 'Add' }} Product</h3>
<form action="{{ $product->exists ? route('admin.products.update', $product) : route('admin.products.store') }}" method="POST" enctype="multipart/form-data" class="admin-stat-card">
    @csrf
    @if($product->exists) @method('PUT') @endif
    <div class="row g-3">
        <div class="col-md-6">
            <label class="small">Product Name</label>
            <input type="text" name="name" class="form-control" value="{{ old('name', $product->name) }}" required>
        </div>
        <div class="col-md-6">
            <label class="small">Category</label>
            <select name="category_id" class="form-select" required>
                @foreach($categories as $cat)
                    <option value="{{ $cat->id }}" {{ old('category_id', $product->category_id) == $cat->id ? 'selected' : '' }}>{{ $cat->name }}</option>
                @endforeach
            </select>
        </div>
        <div class="col-md-4">
            <label class="small">Brand</label>
            <input type="text" name="brand" class="form-control" value="{{ old('brand', $product->brand ?? 'Luxe') }}">
        </div>
        <div class="col-md-4">
            <label class="small">SKU</label>
            <input type="text" name="sku" class="form-control" value="{{ old('sku', $product->sku) }}" required>
        </div>
        <div class="col-md-4">
            <label class="small">Stock</label>
            <input type="number" name="stock" class="form-control" value="{{ old('stock', $product->stock ?? 0) }}" required>
        </div>
        <div class="col-md-4">
            <label class="small">Price ($)</label>
            <input type="number" step="0.01" name="price" class="form-control" value="{{ old('price', $product->price) }}" required>
        </div>
        <div class="col-md-4">
            <label class="small">Discount Price ($)</label>
            <input type="number" step="0.01" name="discount_price" class="form-control" value="{{ old('discount_price', $product->discount_price) }}">
        </div>
        <div class="col-md-4">
            <label class="small">Sizes (comma separated)</label>
            <input type="text" name="sizes" class="form-control" value="{{ old('sizes', $product->sizes ? implode(', ', $product->sizes) : '') }}" placeholder="S, M, L, XL">
        </div>
        <div class="col-12">
            <label class="small">Colors (comma separated)</label>
            <input type="text" name="colors" class="form-control" value="{{ old('colors', $product->colors ? implode(', ', $product->colors) : '') }}" placeholder="Black, Navy, Charcoal">
        </div>
        <div class="col-12">
            <label class="small">Short Description</label>
            <input type="text" name="short_description" class="form-control" value="{{ old('short_description', $product->short_description) }}">
        </div>
        <div class="col-12">
            <label class="small">Full Description</label>
            <textarea name="description" class="form-control" rows="4">{{ old('description', $product->description) }}</textarea>
        </div>
        <div class="col-12">
            <label class="small">Product Images (multiple)</label>
            <input type="file" name="images[]" class="form-control" multiple accept="image/*">
        </div>
        <div class="col-md-4">
            <div class="form-check"><input class="form-check-input" type="checkbox" name="is_new_arrival" id="na" {{ old('is_new_arrival', $product->is_new_arrival) ? 'checked' : '' }}><label class="form-check-label small" for="na">New Arrival</label></div>
        </div>
        <div class="col-md-4">
            <div class="form-check"><input class="form-check-input" type="checkbox" name="is_best_seller" id="bs" {{ old('is_best_seller', $product->is_best_seller) ? 'checked' : '' }}><label class="form-check-label small" for="bs">Best Seller</label></div>
        </div>
        <div class="col-md-4">
            <div class="form-check"><input class="form-check-input" type="checkbox" name="is_active" id="ia" {{ old('is_active', $product->exists ? $product->is_active : true) ? 'checked' : '' }}><label class="form-check-label small" for="ia">Active</label></div>
        </div>
    </div>
    <button class="btn-luxe mt-4">Save Product</button>
</form>
@endsection
