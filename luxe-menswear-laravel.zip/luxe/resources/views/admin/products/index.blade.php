@extends('layouts.admin')
@section('title', 'Products — Luxe Admin')
@section('content')
<div class="d-flex justify-content-between mb-4">
    <h3>Products</h3>
    <a href="{{ route('admin.products.create') }}" class="btn-luxe">+ Add Product</a>
</div>
<form method="GET" class="mb-3"><input type="text" name="q" value="{{ request('q') }}" class="form-control" placeholder="Search products..." style="max-width:320px;"></form>
<div class="admin-stat-card">
    <table class="table table-luxe align-middle">
        <thead><tr><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Status</th><th></th></tr></thead>
        <tbody>
            @foreach($products as $p)
                <tr>
                    <td><img src="{{ image_url(optional($p->images->first())->path) }}" style="width:44px;height:50px;object-fit:cover;border-radius:2px;"></td>
                    <td>{{ $p->name }}</td>
                    <td>{{ $p->category->name ?? '—' }}</td>
                    <td>${{ number_format($p->final_price,2) }}</td>
                    <td>{{ $p->stock }}</td>
                    <td><span class="badge {{ $p->is_active ? 'bg-success' : 'bg-secondary' }}">{{ $p->is_active ? 'Active' : 'Hidden' }}</span></td>
                    <td class="text-nowrap">
                        <a href="{{ route('admin.products.edit', $p) }}" class="small me-2">Edit</a>
                        <form action="{{ route('admin.products.destroy', $p) }}" method="POST" class="d-inline" onsubmit="return confirm('Delete this product?')">
                            @csrf @method('DELETE')
                            <button class="btn btn-link btn-sm text-danger p-0">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    {{ $products->links() }}
</div>
@endsection
