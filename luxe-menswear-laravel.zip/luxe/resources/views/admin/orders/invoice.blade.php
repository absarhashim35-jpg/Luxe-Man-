<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Invoice {{ $order->order_number }}</title>
<style>
body{font-family:Arial,sans-serif;color:#171717;padding:40px;}
h1{color:#111;} table{width:100%;border-collapse:collapse;margin-top:20px;}
th,td{border:1px solid #eee;padding:10px;text-align:left;font-size:14px;}
th{background:#f5f5f5;} .brand{color:#C9A96E;font-weight:700;}
</style>
</head>
<body>
    <h1>LUXE <span class="brand">Invoice</span></h1>
    <p>Order #: {{ $order->order_number }}<br>Date: {{ $order->created_at->format('M d, Y') }}</p>
    <p><strong>Bill To:</strong><br>{{ $order->full_name }}<br>{{ $order->address_line }}<br>{{ $order->city }}, {{ $order->state }} {{ $order->postal_code }}<br>{{ $order->country }}</p>
    <table>
        <thead><tr><th>Product</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead>
        <tbody>
        @foreach($order->items as $item)
            <tr><td>{{ $item->product_name }}</td><td>{{ $item->quantity }}</td><td>${{ number_format($item->price,2) }}</td><td>${{ number_format($item->line_total,2) }}</td></tr>
        @endforeach
        </tbody>
    </table>
    <p style="text-align:right;margin-top:20px;">
        Subtotal: ${{ number_format($order->subtotal,2) }}<br>
        Shipping: ${{ number_format($order->shipping_cost,2) }}<br>
        Discount: -${{ number_format($order->discount,2) }}<br>
        <strong>Grand Total: ${{ number_format($order->grand_total,2) }}</strong>
    </p>
</body>
</html>
