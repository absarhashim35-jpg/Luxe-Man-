@extends('layouts.admin')
@section('title', 'Orders — Luxe Admin')
@section('content')
<h3 class="mb-4">Orders</h3>
<form method="GET" class="mb-3 d-flex gap-2">
    <select name="status" class="form-select" style="max-width:220px;" onchange="this.form.submit()">
        <option value="">All Statuses</option>
        @foreach(\App\Models\Order::STATUSES as $key => $label)
            <option value="{{ $key }}" {{ request('status')==$key?'selected':'' }}>{{ $label }}</option>
        @endforeach
    </select>
</form>
<div class="admin-stat-card">
    <table class="table table-luxe align-middle">
        <thead><tr><th>Order #</th><th>Customer</th><th>Date</th><th>Total</th><th>Payment</th><th>Status</th><th></th></tr></thead>
        <tbody>
            @foreach($orders as $order)
                <tr>
                    <td>{{ $order->order_number }}</td>
                    <td>{{ $order->full_name }}</td>
                    <td>{{ $order->created_at->format('M d, Y') }}</td>
                    <td>${{ number_format($order->grand_total,2) }}</td>
                    <td><span class="badge {{ $order->payment_status=='paid'?'bg-success':'bg-secondary' }}">{{ ucfirst($order->payment_status) }}</span></td>
                    <td><span class="badge bg-dark">{{ \App\Models\Order::STATUSES[$order->status] }}</span></td>
                    <td><a href="{{ route('admin.orders.show', $order) }}" class="small">View</a></td>
                </tr>
            @endforeach
        </tbody>
    </table>
    {{ $orders->links() }}
</div>
@endsection
