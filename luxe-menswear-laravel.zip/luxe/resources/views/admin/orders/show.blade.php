@extends('layouts.admin')
@section('title', 'Order ' . $order->order_number . ' — Luxe Admin')
@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h3>Order {{ $order->order_number }}</h3>
    <a href="{{ route('admin.orders.invoice', $order) }}" target="_blank" class="btn-luxe-outline">Print Invoice</a>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="admin-stat-card mb-4">
            <h6 class="mb-3">Items</h6>
            <table class="table table-luxe">
                <thead><tr><th>Product</th><th>Size/Color</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead>
                <tbody>
                    @foreach($order->items as $item)
                        <tr>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    @if($item->product_image)
                                        <img src="{{ image_url($item->product_image) }}" style="width:40px;height:46px;object-fit:cover;border-radius:2px;">
                                    @endif
                                    {{ $item->product_name }}
                                </div>
                            </td>
                            <td>{{ $item->size }} {{ $item->color }}</td>
                            <td>{{ $item->quantity }}</td>
                            <td>${{ number_format($item->price,2) }}</td>
                            <td>${{ number_format($item->line_total,2) }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            <div class="text-end">
                <p class="mb-1 small">Subtotal: ${{ number_format($order->subtotal,2) }}</p>
                <p class="mb-1 small">Shipping: ${{ number_format($order->shipping_cost,2) }}</p>
                <p class="mb-1 small">Discount: -${{ number_format($order->discount,2) }}</p>
                <h5>Grand Total: ${{ number_format($order->grand_total,2) }}</h5>
            </div>
        </div>
    </div>

    <div class="col-lg-4">
        <div class="admin-stat-card mb-4">
            <h6 class="mb-3">Customer & Shipping</h6>
            <p class="small mb-1"><strong>{{ $order->full_name }}</strong></p>
            <p class="small mb-1">{{ $order->email }}</p>
            <p class="small mb-1">{{ $order->phone }}</p>
            <p class="small text-muted-luxe">{{ $order->address_line }}, {{ $order->city }}, {{ $order->state }} {{ $order->postal_code }}, {{ $order->country }}</p>
        </div>

        <div class="admin-stat-card mb-4">
            <h6 class="mb-3">Order Status</h6>
            <form action="{{ route('admin.orders.status', $order) }}" method="POST" class="mb-3">
                @csrf @method('PATCH')
                <select name="status" class="form-select mb-2" onchange="this.form.submit()">
                    @foreach(\App\Models\Order::STATUSES as $key => $label)
                        <option value="{{ $key }}" {{ $order->status==$key?'selected':'' }}>{{ $label }}</option>
                    @endforeach
                </select>
            </form>
            <h6 class="mb-3">Payment Status</h6>
            <form action="{{ route('admin.orders.payment-status', $order) }}" method="POST">
                @csrf @method('PATCH')
                <select name="payment_status" class="form-select" onchange="this.form.submit()">
                    @foreach(['pending','paid','failed','refunded'] as $s)
                        <option value="{{ $s }}" {{ $order->payment_status==$s?'selected':'' }}>{{ ucfirst($s) }}</option>
                    @endforeach
                </select>
            </form>
        </div>
    </div>
</div>
@endsection
