@extends('layouts.admin')
@section('title', $customer->name . ' — Luxe Admin')
@section('content')
<h3 class="mb-4">{{ $customer->name }}</h3>
<div class="admin-stat-card mb-4">
    <p class="mb-1"><strong>Email:</strong> {{ $customer->email }}</p>
    <p class="mb-1"><strong>Phone:</strong> {{ $customer->phone ?? '—' }}</p>
    <p class="mb-1"><strong>Email Verified:</strong> {{ $customer->email_verified_at ? $customer->email_verified_at->format('M d, Y') : 'Not Verified' }}</p>
    <p><strong>Joined:</strong> {{ $customer->created_at->format('M d, Y') }}</p>
</div>
<h5 class="mb-3">Orders</h5>
<div class="admin-stat-card">
    <table class="table table-luxe">
        <thead><tr><th>Order #</th><th>Date</th><th>Total</th><th>Status</th></tr></thead>
        <tbody>
            @foreach($orders as $o)
                <tr><td>{{ $o->order_number }}</td><td>{{ $o->created_at->format('M d, Y') }}</td><td>${{ number_format($o->grand_total,2) }}</td><td>{{ \App\Models\Order::STATUSES[$o->status] }}</td></tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
