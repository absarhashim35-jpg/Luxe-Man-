@extends('layouts.admin')
@section('title', 'Customers — Luxe Admin')
@section('content')
<h3 class="mb-4">Customers</h3>
<div class="admin-stat-card">
    <table class="table table-luxe align-middle">
        <thead><tr><th>Name</th><th>Email</th><th>Orders</th><th>Email Verified</th><th></th></tr></thead>
        <tbody>
            @foreach($customers as $c)
                <tr>
                    <td>{{ $c->name }}</td>
                    <td>{{ $c->email }}</td>
                    <td>{{ $c->orders_count }}</td>
                    <td>{{ $c->email_verified_at ? '✅ Verified' : '❌ Not Verified' }}</td>
                    <td><a href="{{ route('admin.customers.show', $c) }}" class="small">View</a></td>
                </tr>
            @endforeach
        </tbody>
    </table>
    {{ $customers->links() }}
</div>
@endsection
