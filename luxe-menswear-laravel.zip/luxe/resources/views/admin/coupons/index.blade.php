@extends('layouts.admin')
@section('title', 'Coupons — Luxe Admin')
@section('content')
<h3 class="mb-4">Coupons</h3>

<div class="admin-stat-card mb-4">
    <h6 class="mb-3">Create Coupon</h6>
    <form action="{{ route('admin.coupons.store') }}" method="POST" class="row g-3">
        @csrf
        <div class="col-md-2"><label class="small">Code</label><input type="text" name="code" class="form-control" required></div>
        <div class="col-md-2">
            <label class="small">Type</label>
            <select name="type" class="form-select">
                <option value="percentage">Percentage</option>
                <option value="fixed">Fixed</option>
            </select>
        </div>
        <div class="col-md-2"><label class="small">Value</label><input type="number" step="0.01" name="value" class="form-control" required></div>
        <div class="col-md-2"><label class="small">Min Order</label><input type="number" step="0.01" name="min_order_amount" class="form-control"></div>
        <div class="col-md-2"><label class="small">Expires</label><input type="date" name="expires_at" class="form-control"></div>
        <div class="col-md-2"><label class="small">Usage Limit</label><input type="number" name="usage_limit" class="form-control"></div>
        <div class="col-12"><button class="btn-luxe">Create Coupon</button></div>
    </form>
</div>

<div class="admin-stat-card">
    <table class="table table-luxe">
        <thead><tr><th>Code</th><th>Type</th><th>Value</th><th>Min Order</th><th>Used</th><th>Expires</th><th></th></tr></thead>
        <tbody>
            @foreach($coupons as $c)
                <tr>
                    <td>{{ $c->code }}</td>
                    <td>{{ ucfirst($c->type) }}</td>
                    <td>{{ $c->type=='percentage' ? $c->value.'%' : '$'.number_format($c->value,2) }}</td>
                    <td>${{ number_format($c->min_order_amount,2) }}</td>
                    <td>{{ $c->used_count }}{{ $c->usage_limit ? '/'.$c->usage_limit : '' }}</td>
                    <td>{{ $c->expires_at ? $c->expires_at->format('M d, Y') : '—' }}</td>
                    <td>
                        <form action="{{ route('admin.coupons.destroy', $c) }}" method="POST" onsubmit="return confirm('Delete coupon?')">
                            @csrf @method('DELETE')
                            <button class="btn btn-link btn-sm text-danger p-0">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
