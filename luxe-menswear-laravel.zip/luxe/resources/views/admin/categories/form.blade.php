@extends('layouts.admin')
@section('title', ($category->exists ? 'Edit' : 'Add') . ' Category — Luxe Admin')
@section('content')
<h3 class="mb-4">{{ $category->exists ? 'Edit' : 'Add' }} Category</h3>
<form action="{{ $category->exists ? route('admin.categories.update', $category) : route('admin.categories.store') }}" method="POST" enctype="multipart/form-data" class="admin-stat-card">
    @csrf
    @if($category->exists) @method('PUT') @endif
    <div class="row g-3">
        <div class="col-md-6">
            <label class="small">Category Name</label>
            <input type="text" name="name" class="form-control" value="{{ old('name', $category->name) }}" required>
        </div>
        <div class="col-md-6">
            <label class="small">Sort Order</label>
            <input type="number" name="sort_order" class="form-control" value="{{ old('sort_order', $category->sort_order) }}">
        </div>
        <div class="col-12">
            <label class="small">Description</label>
            <textarea name="description" class="form-control" rows="3">{{ old('description', $category->description) }}</textarea>
        </div>
        <div class="col-12">
            <label class="small">Image</label>
            <input type="file" name="image" class="form-control" accept="image/*">
        </div>
        <div class="col-12">
            <div class="form-check"><input class="form-check-input" type="checkbox" name="is_active" id="ia" {{ old('is_active', $category->exists ? $category->is_active : true) ? 'checked' : '' }}><label class="form-check-label small" for="ia">Active</label></div>
        </div>
    </div>
    <button class="btn-luxe mt-4">Save Category</button>
</form>
@endsection
