@extends('layouts.admin')
@section('title', 'Categories — Luxe Admin')
@section('content')
<div class="d-flex justify-content-between mb-4">
    <h3>Categories</h3>
    <a href="{{ route('admin.categories.create') }}" class="btn-luxe">+ Add Category</a>
</div>
<div class="admin-stat-card">
    <table class="table table-luxe align-middle">
        <thead><tr><th>Name</th><th>Products</th><th>Status</th><th></th></tr></thead>
        <tbody>
            @foreach($categories as $cat)
                <tr>
                    <td>{{ $cat->name }}</td>
                    <td>{{ $cat->products_count }}</td>
                    <td><span class="badge {{ $cat->is_active ? 'bg-success' : 'bg-secondary' }}">{{ $cat->is_active ? 'Active' : 'Hidden' }}</span></td>
                    <td>
                        <a href="{{ route('admin.categories.edit', $cat) }}" class="small me-2">Edit</a>
                        <form action="{{ route('admin.categories.destroy', $cat) }}" method="POST" class="d-inline" onsubmit="return confirm('Delete this category?')">
                            @csrf @method('DELETE')
                            <button class="btn btn-link btn-sm text-danger p-0">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
