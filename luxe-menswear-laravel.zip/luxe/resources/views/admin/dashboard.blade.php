@extends('layouts.admin')
@section('title', 'Dashboard — Luxe Admin')
@section('content')
<h3 class="mb-4">Dashboard</h3>
<div class="row g-3 mb-4">
    <div class="col-md-2 col-6"><div class="admin-stat-card"><small class="text-muted-luxe">Total Sales</small><h3>${{ number_format($totalSales,2) }}</h3></div></div>
    <div class="col-md-2 col-6"><div class="admin-stat-card"><small class="text-muted-luxe">Orders</small><h3>{{ $totalOrders }}</h3></div></div>
    <div class="col-md-2 col-6"><div class="admin-stat-card"><small class="text-muted-luxe">Customers</small><h3>{{ $totalCustomers }}</h3></div></div>
    <div class="col-md-2 col-6"><div class="admin-stat-card"><small class="text-muted-luxe">Products</small><h3>{{ $totalProducts }}</h3></div></div>
    <div class="col-md-2 col-6"><div class="admin-stat-card"><small class="text-muted-luxe">Pending</small><h3>{{ $pendingOrders }}</h3></div></div>
    <div class="col-md-2 col-6"><div class="admin-stat-card"><small class="text-muted-luxe">Completed</small><h3>{{ $completedOrders }}</h3></div></div>
</div>

<div class="admin-stat-card mb-4">
    <h6 class="mb-3">Revenue — Last 14 Days</h6>
    <div class="d-flex align-items-end gap-2" style="height:180px;">
        @php $max = $revenueChart->max('total') ?: 1; @endphp
        @forelse($revenueChart as $row)
            <div class="text-center flex-fill">
                <div style="background:#C9A96E;height:{{ max(4, ($row->total/$max)*150) }}px;border-radius:2px 2px 0 0;"></div>
                <small class="text-muted-luxe" style="font-size:0.6rem;">{{ \Carbon\Carbon::parse($row->day)->format('d M') }}</small>
            </div>
        @empty
            <p class="text-muted-luxe">No sales data yet.</p>
        @endforelse
    </div>
</div>

<div class="admin-stat-card">
    <h6 class="mb-3">Recent Orders</h6>
    <table class="table table-luxe">
        <thead><tr><th>Order #</th><th>Customer</th><th>Total</th><th>Status</th><th></th></tr></thead>
        <tbody>
            @foreach($recentOrders as $order)
                <tr>
                    <td>{{ $order->order_number }}</td>
                    <td>{{ $order->full_name }}</td>
                    <td>${{ number_format($order->grand_total,2) }}</td>
                    <td><span class="badge bg-dark">{{ \App\Models\Order::STATUSES[$order->status] }}</span></td>
                    <td><a href="{{ route('admin.orders.show', $order) }}" class="small">View</a></td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
@endsection
