@extends('layouts.app')
@section('title', 'About Us — Luxe')
@section('content')
<div class="container py-5">
    <div class="section-title">
        <span class="eyebrow">Our Story</span>
        <h2>Crafted for the Modern Gentleman</h2>
    </div>
    <div class="row align-items-center g-5">
        <div class="col-lg-6">
            <img src="https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=900&q=80" class="w-100 rounded" style="border-radius:6px;">
        </div>
        <div class="col-lg-6">
            <p>Luxe was founded on a simple belief: that true elegance lies in restraint. Every garment in our collection is chosen for its craftsmanship, its material integrity, and its ability to make a man feel effortlessly composed.</p>
            <p class="text-muted-luxe">From tailored suits to considered accessories, we work with artisans who share our obsession with detail — because luxury isn't loud, it's precise.</p>
        </div>
    </div>
</div>
@endsection
