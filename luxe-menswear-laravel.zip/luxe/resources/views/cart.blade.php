@extends('layouts.app')
@section('title', 'Your Cart — Luxe')

@section('content')
<div class="container py-5">
    <div class="section-title"><h2>Shopping Cart</h2></div>

    @if($cart->items->isEmpty())
        <div class="text-center py-5">
            <p class="text-muted-luxe mb-4">Your cart is currently empty.</p>
            <a href="{{ route('shop.index') }}" class="btn-luxe">Continue Shopping</a>
        </div>
    @else
        @php
            $subtotal = $cart->subtotal;
            $shipping = $subtotal >= 200 ? 0 : 15;
            $discount = $coupon && $coupon->isValidFor($subtotal) ? $coupon->calculateDiscount($subtotal) : 0;
            $total = max(0, $subtotal + $shipping - $discount);
        @endphp
        <div class="row g-4">
            <div class="col-lg-8">
                @foreach($cart->items as $item)
                    <div class="d-flex align-items-center justify-content-between border-bottom py-3 cart-item-row">
                        <div class="d-flex align-items-center gap-3">
                            <img src="{{ image_url(optional($item->product->images->first())->path) }}" alt="">
                            <div>
                                <a href="{{ route('product.show', $item->product->slug) }}" class="fw-semibold d-block text-dark">{{ $item->product->name }}</a>
                                <div class="small text-muted-luxe">
                                    @if($item->size) Size: {{ $item->size }} @endif
                                    @if($item->color) &middot; Color: {{ $item->color }} @endif
                                </div>
                                <div class="fw-semibold mt-1">${{ number_format($item->price, 2) }}</div>
                            </div>
                        </div>
                        <div class="d-flex align-items-center gap-4">
                            <form action="{{ route('cart.update', $item) }}" method="POST" class="d-flex align-items-center">
                                @csrf @method('PATCH')
                                <div class="qty-control">
                                    <button type="button" data-qty-decrease="#qty-{{ $item->id }}">−</button>
                                    <input type="number" name="quantity" id="qty-{{ $item->id }}" value="{{ $item->quantity }}" min="1" max="20" onchange="this.form.submit()">
                                    <button type="button" data-qty-increase="#qty-{{ $item->id }}">+</button>
                                </div>
                            </form>
                            <span class="fw-semibold">${{ number_format($item->line_total, 2) }}</span>
                            <form action="{{ route('cart.remove', $item) }}" method="POST">
                                @csrf @method('DELETE')
                                <button class="btn btn-link text-danger p-0"><i class="bi bi-trash"></i></button>
                            </form>
                        </div>
                    </div>
                @endforeach

                <div class="mt-4">
                    <a href="{{ route('shop.index') }}" class="btn-luxe-outline"><i class="bi bi-arrow-left me-2"></i>Continue Shopping</a>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="summary-box">
                    <h5 class="mb-4">Order Summary</h5>

                    <form action="{{ route('cart.coupon.apply') }}" method="POST" class="d-flex gap-2 mb-4">
                        @csrf
                        <input type="text" name="code" class="form-control form-control-sm" placeholder="Coupon code" value="{{ $coupon->code ?? '' }}">
                        <button class="btn btn-dark btn-sm" style="border-radius:2px;">Apply</button>
                    </form>
                    @error('code') <div class="text-danger small mb-3">{{ $message }}</div> @enderror

                    <div class="d-flex justify-content-between small mb-2"><span>Subtotal</span><span>${{ number_format($subtotal, 2) }}</span></div>
                    <div class="d-flex justify-content-between small mb-2"><span>Shipping</span><span>{{ $shipping == 0 ? 'Free' : '$'.number_format($shipping,2) }}</span></div>
                    @if($discount > 0)
                        <div class="d-flex justify-content-between small mb-2 text-success"><span>Discount ({{ $coupon->code }})</span><span>-${{ number_format($discount, 2) }}</span></div>
                    @endif
                    <hr>
                    <div class="d-flex justify-content-between fw-bold fs-5 mb-4"><span>Total</span><span>${{ number_format($total, 2) }}</span></div>

                    <a href="{{ route('checkout.index') }}" class="btn-luxe w-100 text-center d-block">Proceed to Checkout</a>
                </div>
            </div>
        </div>
    @endif
</div>
@endsection
