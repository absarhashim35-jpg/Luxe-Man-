@extends('layouts.app')
@section('title', 'Track Your Order — Luxe')

@section('content')
<div class="container py-5">
    <div class="section-title"><h2>Track Your Order</h2></div>

    <div class="row justify-content-center">
        <div class="col-lg-6">
            <form action="{{ route('order.track') }}" method="POST" class="filter-box mb-5">
                @csrf
                <div class="mb-3">
                    <label class="small">Order Number</label>
                    <input type="text" name="order_number" class="form-control @error('order_number') is-invalid @enderror" placeholder="LUXE-20260101-ABC123" required>
                    @error('order_number')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
                <div class="mb-3">
                    <label class="small">Email Used at Checkout</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <button class="btn-luxe w-100">Track Order</button>
            </form>
        </div>
    </div>

    @isset($order)
        @php
            $steps = \App\Models\Order::STATUSES;
            $keys = array_keys($steps);
            $currentIndex = array_search($order->status, $keys);
        @endphp
        <div class="filter-box">
            <div class="d-flex justify-content-between mb-3">
                <div><strong>Order #{{ $order->order_number }}</strong></div>
                <div class="text-muted-luxe small">Placed {{ $order->created_at->format('M d, Y') }}</div>
            </div>

            @if($order->status !== 'cancelled')
                <div class="track-steps">
                    @foreach($steps as $key => $label)
                        @if($key !== 'cancelled')
                            <div class="track-step {{ array_search($key, $keys) <= $currentIndex ? 'done' : '' }}">
                                <div class="dot"><i class="bi bi-check"></i></div>
                                <small>{{ $label }}</small>
                            </div>
                        @endif
                    @endforeach
                </div>
            @else
                <div class="alert alert-danger">This order was cancelled.</div>
            @endif

            <hr>
            @foreach($order->items as $item)
                <div class="d-flex justify-content-between border-bottom py-2 small">
                    <span>{{ $item->product_name }} &times; {{ $item->quantity }}</span>
                    <span>${{ number_format($item->line_total, 2) }}</span>
                </div>
            @endforeach
            <div class="d-flex justify-content-between pt-3 fw-bold">
                <span>Grand Total</span><span>${{ number_format($order->grand_total, 2) }}</span>
            </div>
        </div>
    @endisset
</div>
@endsection
