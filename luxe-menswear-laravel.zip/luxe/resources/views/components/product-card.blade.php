@props(['product'])
<div class="product-card h-100">
    <div class="img-wrap">
        <a href="{{ route('product.show', $product->slug) }}">
            <img src="{{ image_url(optional($product->images->first())->path) }}" alt="{{ $product->name }}">
        </a>
        @if($product->is_on_sale)
            <span class="discount-badge">-{{ $product->discount_percent }}%</span>
        @endif
        @auth
            <form action="{{ route('wishlist.toggle') }}" method="POST" class="ajax-wishlist">
                @csrf
                <input type="hidden" name="product_id" value="{{ $product->id }}">
                <button type="submit" class="wishlist-btn"><i class="bi bi-heart"></i></button>
            </form>
        @else
            <a href="{{ route('login') }}" class="wishlist-btn"><i class="bi bi-heart"></i></a>
        @endauth
    </div>
    <div class="body">
        <div class="cat">{{ $product->category->name ?? '' }}</div>
        <div class="name"><a href="{{ route('product.show', $product->slug) }}">{{ $product->name }}</a></div>
        <div class="rating mb-1">
            @for($i=1;$i<=5;$i++)
                <i class="bi bi-star{{ $i <= round($product->rating) ? '-fill' : '' }}"></i>
            @endfor
            <span class="text-muted-luxe small">({{ $product->rating_count }})</span>
        </div>
        <div class="price">
            <span class="now">${{ number_format($product->final_price, 2) }}</span>
            @if($product->is_on_sale)
                <span class="old">${{ number_format($product->price, 2) }}</span>
            @endif
        </div>
        <form action="{{ route('cart.add') }}" method="POST" class="ajax-add-cart">
            @csrf
            <input type="hidden" name="product_id" value="{{ $product->id }}">
            <button type="submit" class="add-cart-btn" {{ !$product->in_stock ? 'disabled' : '' }}>
                {{ $product->in_stock ? 'Add to Cart' : 'Out of Stock' }}
            </button>
        </form>
    </div>
</div>
