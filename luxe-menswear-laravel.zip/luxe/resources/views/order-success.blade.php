@extends('layouts.app')
@section('title', 'Order Confirmed — Luxe')

@section('content')
<div class="container py-5 text-center">
    <div class="mb-4" style="font-size:3.5rem;color:#C9A96E;"><i class="bi bi-check-circle"></i></div>
    <h2>Thank You — Your Order is Confirmed</h2>
    <p class="text-muted-luxe">Order number <strong>{{ $order->order_number }}</strong>. A confirmation email has been sent to {{ $order->email }}.</p>

    <div class="row justify-content-center mt-5">
        <div class="col-lg-6 text-start">
            <div class="filter-box">
                @foreach($order->items as $item)
                    <div class="d-flex justify-content-between border-bottom py-2">
                        <span class="small">{{ $item->product_name }} @if($item->size) ({{ $item->size }}@if($item->color), {{ $item->color }}@endif) @endif &times; {{ $item->quantity }}</span>
                        <span class="small fw-semibold">${{ number_format($item->line_total, 2) }}</span>
                    </div>
                @endforeach
                <div class="d-flex justify-content-between pt-3 fw-bold">
                    <span>Grand Total</span><span>${{ number_format($order->grand_total, 2) }}</span>
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex gap-3 justify-content-center mt-5">
        <a href="{{ route('order.track.form') }}" class="btn-luxe-outline">Track Order</a>
        <a href="{{ route('shop.index') }}" class="btn-luxe">Continue Shopping</a>
    </div>
</div>
@endsection
