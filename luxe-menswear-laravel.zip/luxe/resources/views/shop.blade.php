@extends('layouts.app')
@section('title', 'Shop — Luxe')

@section('content')
<div class="container py-5">
    <div class="section-title">
        <span class="eyebrow">The Collection</span>
        <h2>Shop All</h2>
    </div>

    <div class="row g-4">
        <div class="col-lg-3">
            <form method="GET" action="{{ route('shop.index') }}">
                <div class="filter-box mb-3">
                    <h6>Search</h6>
                    <input type="text" name="q" value="{{ request('q') }}" class="form-control" placeholder="Search products...">
                </div>

                <div class="filter-box mb-3">
                    <h6>Category</h6>
                    @foreach($categories as $cat)
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="category" value="{{ $cat->slug }}" id="cat{{ $cat->id }}" {{ request('category') == $cat->slug ? 'checked' : '' }} onchange="this.form.submit()">
                            <label class="form-check-label small" for="cat{{ $cat->id }}">{{ $cat->name }}</label>
                        </div>
                    @endforeach
                </div>

                <div class="filter-box mb-3">
                    <h6>Price Range</h6>
                    <div class="d-flex gap-2">
                        <input type="number" name="min_price" value="{{ request('min_price') }}" class="form-control form-control-sm" placeholder="Min">
                        <input type="number" name="max_price" value="{{ request('max_price') }}" class="form-control form-control-sm" placeholder="Max">
                    </div>
                </div>

                <div class="filter-box mb-3">
                    <h6>Size</h6>
                    <select name="size" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="">Any Size</option>
                        @foreach(['S','M','L','XL','XXL','38','40','42','44'] as $s)
                            <option value="{{ $s }}" {{ request('size') == $s ? 'selected' : '' }}>{{ $s }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="filter-box mb-3">
                    <h6>Color</h6>
                    <select name="color" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="">Any Color</option>
                        @foreach(['Black','Navy','Charcoal','Grey','White','Brown','Tan','Burgundy'] as $c)
                            <option value="{{ $c }}" {{ request('color') == $c ? 'selected' : '' }}>{{ $c }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="filter-box mb-3">
                    <h6>Brand</h6>
                    <select name="brand" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="">Any Brand</option>
                        @foreach($brands as $b)
                            <option value="{{ $b }}" {{ request('brand') == $b ? 'selected' : '' }}>{{ $b }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="filter-box mb-3">
                    <h6>Rating</h6>
                    <select name="rating" class="form-select form-select-sm" onchange="this.form.submit()">
                        <option value="">Any Rating</option>
                        @foreach([4,3,2,1] as $r)
                            <option value="{{ $r }}" {{ request('rating') == $r ? 'selected' : '' }}>{{ $r }}+ Stars</option>
                        @endforeach
                    </select>
                </div>

                <button class="btn-luxe w-100">Apply Filters</button>
                <a href="{{ route('shop.index') }}" class="btn-luxe-outline w-100 mt-2 text-center">Clear</a>
                <input type="hidden" name="sort" value="{{ request('sort') }}">
            </form>
        </div>

        <div class="col-lg-9">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <span class="text-muted-luxe small">{{ $products->total() }} products found</span>
                <form method="GET" action="{{ route('shop.index') }}" class="d-flex align-items-center gap-2">
                    @foreach(request()->except('sort') as $k => $v)
                        <input type="hidden" name="{{ $k }}" value="{{ $v }}">
                    @endforeach
                    <label class="small text-muted-luxe mb-0">Sort:</label>
                    <select name="sort" class="form-select form-select-sm" onchange="this.form.submit()" style="width:auto;">
                        <option value="latest" {{ request('sort','latest')=='latest'?'selected':'' }}>Latest</option>
                        <option value="price_low" {{ request('sort')=='price_low'?'selected':'' }}>Price: Low to High</option>
                        <option value="price_high" {{ request('sort')=='price_high'?'selected':'' }}>Price: High to Low</option>
                        <option value="popular" {{ request('sort')=='popular'?'selected':'' }}>Popular</option>
                        <option value="rated" {{ request('sort')=='rated'?'selected':'' }}>Best Rated</option>
                    </select>
                </form>
            </div>

            <div class="row g-4">
                @forelse($products as $product)
                    <div class="col-lg-4 col-md-6">
                        <x-product-card :product="$product" />
                    </div>
                @empty
                    <div class="col-12 text-center py-5 text-muted-luxe">No products match your filters.</div>
                @endforelse
            </div>

            <div class="mt-5">{{ $products->links() }}</div>
        </div>
    </div>
</div>
@endsection
