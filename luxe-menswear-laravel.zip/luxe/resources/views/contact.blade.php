@extends('layouts.app')
@section('title', 'Contact Us — Luxe')
@section('content')
<div class="container py-5">
    <div class="section-title">
        <span class="eyebrow">Get in Touch</span>
        <h2>Contact Us</h2>
    </div>
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <form action="{{ route('contact.submit') }}" method="POST" class="filter-box">
                @csrf
                <div class="mb-3">
                    <label class="small">Name</label>
                    <input type="text" name="name" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label class="small">Email</label>
                    <input type="email" name="email" class="form-control" required>
                </div>
                <div class="mb-4">
                    <label class="small">Message</label>
                    <textarea name="message" class="form-control" rows="5" required></textarea>
                </div>
                <button class="btn-luxe w-100">Send Message</button>
            </form>
        </div>
    </div>
</div>
@endsection
