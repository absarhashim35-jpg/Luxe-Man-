@extends('layouts.app')
@section('title', 'Checkout — Luxe')

@section('content')
<div class="container py-5">
    <div class="section-title"><h2>Checkout</h2></div>

    @php
        $subtotal = $cart->subtotal;
        $shipping = $subtotal >= 200 ? 0 : 15;
        $discount = $coupon && $coupon->isValidFor($subtotal) ? $coupon->calculateDiscount($subtotal) : 0;
        $total = max(0, $subtotal + $shipping - $discount);
    @endphp

    <form action="{{ route('checkout.store') }}" method="POST">
        @csrf
        <div class="row g-5">
            <div class="col-lg-7">
                <h5 class="mb-3">Customer Information</h5>
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="small">Full Name</label>
                        <input type="text" name="full_name" class="form-control @error('full_name') is-invalid @enderror" value="{{ old('full_name', auth()->user()->name ?? '') }}" required>
                        @error('full_name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-6">
                        <label class="small">Email</label>
                        <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email', auth()->user()->email ?? '') }}" required>
                        @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-6">
                        <label class="small">Phone</label>
                        <input type="text" name="phone" class="form-control @error('phone') is-invalid @enderror" value="{{ old('phone', auth()->user()->phone ?? '') }}" required>
                        @error('phone')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-6">
                        <label class="small">Country</label>
                        <input type="text" name="country" class="form-control @error('country') is-invalid @enderror" value="{{ old('country') }}" required>
                        @error('country')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-12">
                        <label class="small">Complete Address</label>
                        <input type="text" name="address_line" class="form-control @error('address_line') is-invalid @enderror" value="{{ old('address_line') }}" required>
                        @error('address_line')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-4">
                        <label class="small">City</label>
                        <input type="text" name="city" class="form-control @error('city') is-invalid @enderror" value="{{ old('city') }}" required>
                        @error('city')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                    <div class="col-md-4">
                        <label class="small">State / Province</label>
                        <input type="text" name="state" class="form-control" value="{{ old('state') }}">
                    </div>
                    <div class="col-md-4">
                        <label class="small">Postal Code</label>
                        <input type="text" name="postal_code" class="form-control @error('postal_code') is-invalid @enderror" value="{{ old('postal_code') }}" required>
                        @error('postal_code')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    </div>
                </div>

                <h5 class="mb-3">Payment Method</h5>
                <div class="filter-box">
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="payment_method" id="pm_cod" value="cod" checked>
                        <label class="form-check-label" for="pm_cod">Cash on Delivery</label>
                    </div>
                    <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="payment_method" id="pm_bank" value="bank_transfer">
                        <label class="form-check-label" for="pm_bank">Bank Transfer</label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="payment_method" id="pm_online" value="online">
                        <label class="form-check-label" for="pm_online">Online Payment (Card — via payment gateway)</label>
                    </div>
                    <p class="small text-muted-luxe mt-2 mb-0">Online payment gateway integration (Stripe/PayPal) can be wired into this option — the order pipeline already supports a "paid" status transition.</p>
                </div>
            </div>

            <div class="col-lg-5">
                <div class="summary-box">
                    <h5 class="mb-4">Your Order</h5>
                    @foreach($cart->items as $item)
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <div class="d-flex align-items-center gap-2">
                                <img src="{{ image_url(optional($item->product->images->first())->path) }}" style="width:52px;height:60px;object-fit:cover;border-radius:2px;">
                                <div>
                                    <div class="small fw-semibold">{{ $item->product->name }}</div>
                                    <div class="small text-muted-luxe">Qty: {{ $item->quantity }} @if($item->size) &middot; {{ $item->size }} @endif</div>
                                </div>
                            </div>
                            <span class="small fw-semibold">${{ number_format($item->line_total, 2) }}</span>
                        </div>
                    @endforeach
                    <hr>
                    <div class="d-flex justify-content-between small mb-2"><span>Subtotal</span><span>${{ number_format($subtotal, 2) }}</span></div>
                    <div class="d-flex justify-content-between small mb-2"><span>Shipping</span><span>{{ $shipping == 0 ? 'Free' : '$'.number_format($shipping,2) }}</span></div>
                    @if($discount > 0)
                        <div class="d-flex justify-content-between small mb-2 text-success"><span>Discount</span><span>-${{ number_format($discount, 2) }}</span></div>
                    @endif
                    <hr>
                    <div class="d-flex justify-content-between fw-bold fs-5 mb-4"><span>Grand Total</span><span>${{ number_format($total, 2) }}</span></div>
                    <button type="submit" class="btn-luxe w-100">Place Order</button>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection
