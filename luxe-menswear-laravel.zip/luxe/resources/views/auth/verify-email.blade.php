@extends('layouts.app')
@section('title', 'Verify Your Email — Luxe')
@section('content')
<div class="auth-wrap">
    <div class="auth-card text-center">
        <div class="mb-3" style="font-size:2.5rem;color:#C9A96E;"><i class="bi bi-envelope-check"></i></div>
        <h3 class="font-serif mb-3">Verify Your Email</h3>
        <p class="text-muted-luxe small mb-4">
            We've sent a verification link to <strong>{{ auth()->user()->email }}</strong>.
            Please click the link to activate your account. Didn't receive it?
        </p>
        <form method="POST" action="{{ route('verification.send') }}">
            @csrf
            <button class="btn-luxe w-100">Resend Verification Email</button>
        </form>
        <form method="POST" action="{{ route('logout') }}" class="mt-3">
            @csrf
            <button class="btn btn-link small text-muted-luxe">Logout</button>
        </form>
    </div>
</div>
@endsection
