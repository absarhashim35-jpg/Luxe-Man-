@extends('layouts.app')
@section('title', 'Sign In — Luxe')
@section('content')
<div class="auth-wrap">
    <div class="auth-card">
        <div class="text-center mb-4">
            <h3 class="font-serif">Welcome Back</h3>
            <p class="text-muted-luxe small">Sign in to your Luxe account.</p>
        </div>
        <form method="POST" action="{{ route('login') }}">
            @csrf
            <div class="mb-3">
                <label class="small">Email</label>
                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email') }}" required autofocus>
                @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="mb-3">
                <label class="small">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="remember" id="remember">
                    <label class="form-check-label small" for="remember">Remember me</label>
                </div>
                <a href="{{ route('password.request') }}" class="small text-gold">Forgot password?</a>
            </div>
            <button class="btn-luxe w-100">Sign In</button>
        </form>
        <p class="text-center small mt-4">New to Luxe? <a href="{{ route('register') }}" class="text-gold">Create an account</a></p>
    </div>
</div>
@endsection
