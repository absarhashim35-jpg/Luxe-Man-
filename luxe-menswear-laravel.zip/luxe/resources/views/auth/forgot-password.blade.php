@extends('layouts.app')
@section('title', 'Forgot Password — Luxe')
@section('content')
<div class="auth-wrap">
    <div class="auth-card">
        <h3 class="font-serif text-center mb-2">Reset Your Password</h3>
        <p class="text-muted-luxe small text-center mb-4">Enter your email and we'll send you a reset link.</p>
        <form method="POST" action="{{ route('password.email') }}">
            @csrf
            <div class="mb-4">
                <label class="small">Email</label>
                <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" value="{{ old('email') }}" required autofocus>
                @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <button class="btn-luxe w-100">Send Reset Link</button>
        </form>
    </div>
</div>
@endsection
