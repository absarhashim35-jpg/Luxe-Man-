@extends('layouts.app')
@section('title', $product->name . ' — Luxe')

@section('content')
<div class="container py-5">
    <nav class="small text-muted-luxe mb-4">
        <a href="{{ route('home') }}">Home</a> / <a href="{{ route('shop.index') }}">Shop</a> / {{ $product->category->name ?? '' }} / <span class="text-dark">{{ $product->name }}</span>
    </nav>

    <div class="row g-5">
        <div class="col-lg-6">
            @php $images = $product->images->count() ? $product->images : collect([(object)['path'=>null]]); @endphp
            <img src="{{ image_url($images->first()->path, 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=900&q=80') }}"
                 class="main-product-img mb-3" data-zoom alt="{{ $product->name }}">
            <div class="d-flex gap-2 thumb-list flex-wrap">
                @foreach($images as $i => $img)
                    <img src="{{ image_url($img->path, 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=200&q=80') }}"
                         data-full="{{ image_url($img->path, 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=900&q=80') }}"
                         class="{{ $i === 0 ? 'active' : '' }}">
                @endforeach
            </div>
        </div>

        <div class="col-lg-6">
            <div class="eyebrow">{{ $product->category->name ?? '' }} &middot; {{ $product->brand }}</div>
            <h1 class="mb-2">{{ $product->name }}</h1>
            <div class="rating mb-3">
                @for($i=1;$i<=5;$i++)<i class="bi bi-star{{ $i <= round($product->rating) ? '-fill' : '' }} text-gold"></i>@endfor
                <span class="text-muted-luxe small ms-1">{{ $product->rating }} ({{ $product->rating_count }} reviews)</span>
            </div>

            <div class="mb-3">
                <span class="fs-3 fw-bold">${{ number_format($product->final_price, 2) }}</span>
                @if($product->is_on_sale)
                    <span class="text-muted-luxe text-decoration-line-through ms-2">${{ number_format($product->price, 2) }}</span>
                    <span class="badge bg-dark ms-2">-{{ $product->discount_percent }}%</span>
                @endif
            </div>

            <p class="text-muted-luxe">{{ $product->short_description }}</p>

            <div class="mb-2">
                @if($product->in_stock)
                    <span class="badge" style="background:#e9f7ef;color:#1e7e34;">In Stock ({{ $product->stock }} available)</span>
                @else
                    <span class="badge bg-danger">Out of Stock</span>
                @endif
            </div>

            <form action="{{ route('cart.add') }}" method="POST" class="ajax-add-cart mt-4">
                @csrf
                <input type="hidden" name="product_id" value="{{ $product->id }}">

                @if($product->sizes)
                    <div class="mb-3 size-options">
                        <label class="small fw-semibold mb-2 d-block">Size</label>
                        <div class="d-flex gap-2 flex-wrap">
                            @foreach($product->sizes as $i => $size)
                                <div class="size-box {{ $i===0?'active':'' }}" data-size="{{ $size }}">{{ $size }}</div>
                            @endforeach
                        </div>
                        <input type="hidden" name="size" id="selected_size" value="{{ $product->sizes[0] ?? '' }}">
                    </div>
                @endif

                @if($product->colors)
                    <div class="mb-3 color-options">
                        <label class="small fw-semibold mb-2 d-block">Color</label>
                        <div class="d-flex gap-2 flex-wrap">
                            @foreach($product->colors as $i => $color)
                                <div class="swatch {{ $i===0?'active':'' }}" data-color="{{ $color }}" title="{{ $color }}" style="background:{{ strtolower($color) }};color:#fff;">{{ $i===0 ? '✓' : '' }}</div>
                            @endforeach
                        </div>
                        <input type="hidden" name="color" id="selected_color" value="{{ $product->colors[0] ?? '' }}">
                    </div>
                @endif

                <div class="mb-4">
                    <label class="small fw-semibold mb-2 d-block">Quantity</label>
                    <div class="qty-control">
                        <button type="button" data-qty-decrease="#qty_input">−</button>
                        <input type="number" name="quantity" id="qty_input" value="1" min="1" max="20">
                        <button type="button" data-qty-increase="#qty_input">+</button>
                    </div>
                </div>

                <div class="d-flex gap-3 flex-wrap">
                    <button type="submit" class="btn-luxe" {{ !$product->in_stock ? 'disabled' : '' }}>Add to Cart</button>
                    <a href="{{ route('checkout.index') }}" class="btn-luxe-outline">Buy Now</a>
                    @auth
                        <button type="button" class="btn-luxe-outline" onclick="document.getElementById('wishlist-form-{{$product->id}}').requestSubmit()"><i class="bi bi-heart"></i></button>
                    @endauth
                </div>
            </form>

            @auth
                <form id="wishlist-form-{{$product->id}}" action="{{ route('wishlist.toggle') }}" method="POST" class="d-none">
                    @csrf
                    <input type="hidden" name="product_id" value="{{ $product->id }}">
                </form>
            @endauth

            <hr class="my-4">
            <div class="row small text-muted-luxe">
                <div class="col-6"><i class="bi bi-truck me-1"></i> Free shipping over $200</div>
                <div class="col-6"><i class="bi bi-arrow-repeat me-1"></i> 30-day easy returns</div>
            </div>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col-lg-8">
            <ul class="nav nav-tabs" id="pdTabs">
                <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#desc">Description</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#specs">Specifications</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#shipping">Shipping & Returns</button></li>
                <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#reviews">Reviews ({{ $product->reviews->count() }})</button></li>
            </ul>
            <div class="tab-content py-4">
                <div class="tab-pane fade show active" id="desc">{!! nl2br(e($product->description)) !!}</div>
                <div class="tab-pane fade" id="specs">
                    <table class="table table-luxe">
                        @foreach(($product->specifications ?? []) as $key => $val)
                            <tr><th class="w-25">{{ $key }}</th><td>{{ $val }}</td></tr>
                        @endforeach
                    </table>
                </div>
                <div class="tab-pane fade" id="shipping">
                    <p><strong>Shipping:</strong> Orders ship within 1-2 business days. Free standard shipping on orders over $200; flat $15 shipping otherwise.</p>
                    <p><strong>Returns:</strong> Unworn items with tags may be returned within 30 days of delivery for a full refund.</p>
                </div>
                <div class="tab-pane fade" id="reviews">
                    @forelse($product->reviews as $review)
                        <div class="mb-3 pb-3 border-bottom">
                            <div class="text-gold">@for($i=1;$i<=5;$i++)<i class="bi bi-star{{ $i<=$review->rating?'-fill':'' }}"></i>@endfor</div>
                            <div class="fw-semibold small">{{ $review->user->name }}</div>
                            <p class="small mb-0">{{ $review->comment }}</p>
                        </div>
                    @empty
                        <p class="text-muted-luxe">No reviews yet — be the first to review this product.</p>
                    @endforelse
                </div>
            </div>
        </div>
    </div>

    @if($related->count())
    <div class="mt-5">
        <div class="section-title"><h2>You May Also Like</h2></div>
        <div class="row g-4">
            @foreach($related as $r)
                <div class="col-lg-3 col-md-6"><x-product-card :product="$r" /></div>
            @endforeach
        </div>
    </div>
    @endif
</div>
@endsection
