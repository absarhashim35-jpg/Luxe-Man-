<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'order_number', 'user_id', 'full_name', 'email', 'phone', 'address_line',
        'city', 'state', 'postal_code', 'country', 'subtotal', 'shipping_cost',
        'discount', 'grand_total', 'coupon_code', 'payment_method', 'payment_status',
        'status', 'notes',
    ];

    public const STATUSES = [
        'placed' => 'Order Placed',
        'confirmed' => 'Order Confirmed',
        'processing' => 'Processing',
        'shipped' => 'Shipped',
        'out_for_delivery' => 'Out for Delivery',
        'delivered' => 'Delivered',
        'cancelled' => 'Cancelled',
    ];

    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public static function generateOrderNumber(): string
    {
        return 'LUXE-' . now()->format('Ymd') . '-' . strtoupper(substr(uniqid(), -6));
    }
}
