<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductImage extends Model
{
    protected $fillable = ['product_id', 'path', 'is_primary', 'sort_order'];

    protected function casts(): array
    {
        return ['is_primary' => 'boolean'];
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    /**
     * Seeded demo products store a full external URL in `path`.
     * Uploaded admin images store a relative storage path.
     * This accessor returns the correct browser-usable URL either way.
     */
    public function getUrlAttribute(): string
    {
        return str_starts_with($this->path, 'http')
            ? $this->path
            : asset('storage/' . $this->path);
    }
}
