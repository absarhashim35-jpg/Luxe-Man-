<?php

namespace App\Mail;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class OrderPlacedAdminMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public Order $order)
    {
        $this->order->loadMissing('items');
    }

    public function build()
    {
        return $this->subject("New Order Received — {$this->order->order_number}")
            ->view('emails.order-admin')
            ->with(['order' => $this->order]);
    }
}
