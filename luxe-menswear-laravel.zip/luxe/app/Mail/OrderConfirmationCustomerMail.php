<?php

namespace App\Mail;

use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class OrderConfirmationCustomerMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(public Order $order)
    {
        $this->order->loadMissing('items');
    }

    public function build()
    {
        return $this->subject("Your Luxe Order Confirmation — {$this->order->order_number}")
            ->view('emails.order-customer')
            ->with(['order' => $this->order]);
    }
}
