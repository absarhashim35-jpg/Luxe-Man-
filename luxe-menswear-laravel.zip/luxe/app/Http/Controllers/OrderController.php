<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function myOrders(Request $request)
    {
        $orders = Order::where('user_id', $request->user()->id)->latest()->paginate(10);
        return view('account.orders', compact('orders'));
    }

    public function show(Request $request, Order $order)
    {
        abort_unless($order->user_id === $request->user()->id, 403);
        $order->load('items');
        return view('account.order-details', compact('order'));
    }

    public function trackForm()
    {
        return view('track-order');
    }

    public function track(Request $request)
    {
        $request->validate(['order_number' => 'required|string', 'email' => 'required|email']);

        $order = Order::where('order_number', $request->order_number)
            ->where('email', $request->email)
            ->with('items')
            ->first();

        if (!$order) {
            return back()->withErrors(['order_number' => 'No order found matching that order number and email.']);
        }

        return view('track-order', compact('order'));
    }
}
