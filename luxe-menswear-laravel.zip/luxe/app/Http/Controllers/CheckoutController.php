<?php

namespace App\Http\Controllers;

use App\Mail\OrderPlacedAdminMail;
use App\Mail\OrderConfirmationCustomerMail;
use App\Models\Cart;
use App\Models\Coupon;
use App\Models\Order;
use App\Models\OrderItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;

class CheckoutController extends Controller
{
    protected function currentCart(Request $request): ?Cart
    {
        if ($request->user()) {
            return Cart::where('user_id', $request->user()->id)->first();
        }
        return Cart::where('session_id', Session::get('cart_session_id'))->first();
    }

    public function index(Request $request)
    {
        $cart = $this->currentCart($request)?->load('items.product');

        if (!$cart || $cart->items->isEmpty()) {
            return redirect()->route('cart.index')->with('error', 'Your cart is empty.');
        }

        $couponCode = Session::get('coupon_code');
        $coupon = $couponCode ? Coupon::where('code', $couponCode)->first() : null;

        return view('checkout', compact('cart', 'coupon'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'full_name' => 'required|string|max:255',
            'email' => 'required|email|max:255',
            'phone' => 'required|string|max:30',
            'address_line' => 'required|string|max:500',
            'city' => 'required|string|max:120',
            'state' => 'nullable|string|max:120',
            'postal_code' => 'required|string|max:20',
            'country' => 'required|string|max:120',
            'payment_method' => 'required|in:cod,bank_transfer,online',
        ]);

        $cart = $this->currentCart($request)?->load('items.product.images');
        if (!$cart || $cart->items->isEmpty()) {
            return redirect()->route('cart.index')->with('error', 'Your cart is empty.');
        }

        $subtotal = $cart->subtotal;
        $shipping = $subtotal >= 200 ? 0 : 15;

        $discount = 0;
        $couponCode = Session::get('coupon_code');
        $coupon = $couponCode ? Coupon::where('code', $couponCode)->first() : null;
        if ($coupon && $coupon->isValidFor($subtotal)) {
            $discount = $coupon->calculateDiscount($subtotal);
        } else {
            $coupon = null;
        }

        $grandTotal = max(0, $subtotal + $shipping - $discount);

        $order = DB::transaction(function () use ($data, $cart, $subtotal, $shipping, $discount, $grandTotal, $coupon, $request) {
            $order = Order::create([
                'order_number' => Order::generateOrderNumber(),
                'user_id' => $request->user()?->id,
                'full_name' => $data['full_name'],
                'email' => $data['email'],
                'phone' => $data['phone'],
                'address_line' => $data['address_line'],
                'city' => $data['city'],
                'state' => $data['state'] ?? null,
                'postal_code' => $data['postal_code'],
                'country' => $data['country'],
                'subtotal' => $subtotal,
                'shipping_cost' => $shipping,
                'discount' => $discount,
                'grand_total' => $grandTotal,
                'coupon_code' => $coupon?->code,
                'payment_method' => $data['payment_method'],
                'payment_status' => 'pending',
                'status' => 'placed',
            ]);

            foreach ($cart->items as $item) {
                OrderItem::create([
                    'order_id' => $order->id,
                    'product_id' => $item->product_id,
                    'product_name' => $item->product->name,
                    'product_image' => optional($item->product->images->first())->path,
                    'size' => $item->size,
                    'color' => $item->color,
                    'quantity' => $item->quantity,
                    'price' => $item->price,
                    'line_total' => $item->price * $item->quantity,
                ]);

                // decrement stock
                $item->product->decrement('stock', $item->quantity);
                $item->product->increment('sold_count', $item->quantity);
            }

            if ($coupon) {
                $coupon->increment('used_count');
            }

            $cart->items()->delete();

            return $order;
        });

        Session::forget('coupon_code');

        $order->load('items');

        // Email the admin + customer. Wrapped so a mail failure never blocks the order.
        try {
            Mail::to(config('mail.admin_order_email', env('ADMIN_ORDER_EMAIL')))->send(new OrderPlacedAdminMail($order));
            Mail::to($order->email)->send(new OrderConfirmationCustomerMail($order));
        } catch (\Throwable $e) {
            report($e);
        }

        return redirect()->route('order.success', $order->order_number);
    }

    public function success(string $orderNumber)
    {
        $order = Order::where('order_number', $orderNumber)->with('items')->firstOrFail();
        return view('order-success', compact('order'));
    }
}
