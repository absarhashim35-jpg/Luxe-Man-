<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ProfileController extends Controller
{
    public function dashboard(Request $request)
    {
        $user = $request->user();
        $recentOrders = $user->orders()->latest()->take(5)->get();
        return view('account.dashboard', compact('user', 'recentOrders'));
    }

    public function edit(Request $request)
    {
        return view('account.profile', ['user' => $request->user()]);
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users,email,' . $request->user()->id,
            'phone' => 'nullable|string|max:30',
        ]);

        $request->user()->update($data);

        return back()->with('success', 'Profile updated successfully.');
    }

    public function updatePassword(Request $request)
    {
        $request->validate([
            'current_password' => 'required|current_password',
            'password' => 'required|min:8|confirmed',
        ]);

        $request->user()->update(['password' => Hash::make($request->password)]);

        return back()->with('success', 'Password changed successfully.');
    }

    public function addresses(Request $request)
    {
        $addresses = $request->user()->addresses;
        return view('account.addresses', compact('addresses'));
    }

    public function storeAddress(Request $request)
    {
        $data = $request->validate([
            'label' => 'nullable|string|max:60',
            'full_name' => 'required|string|max:255',
            'phone' => 'required|string|max:30',
            'address_line' => 'required|string|max:500',
            'city' => 'required|string|max:120',
            'state' => 'nullable|string|max:120',
            'postal_code' => 'required|string|max:20',
            'country' => 'required|string|max:120',
        ]);
        $data['user_id'] = $request->user()->id;
        $data['label'] = $data['label'] ?? 'Home';

        \App\Models\Address::create($data);

        return back()->with('success', 'Address saved.');
    }

    public function deleteAddress(Request $request, \App\Models\Address $address)
    {
        abort_unless($address->user_id === $request->user()->id, 403);
        $address->delete();
        return back()->with('success', 'Address removed.');
    }
}
