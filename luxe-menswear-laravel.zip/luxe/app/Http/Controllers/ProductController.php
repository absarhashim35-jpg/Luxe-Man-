<?php

namespace App\Http\Controllers;

use App\Models\Product;

class ProductController extends Controller
{
    public function show(string $slug)
    {
        $product = Product::active()->with(['images', 'category', 'reviews.user'])
            ->where('slug', $slug)->firstOrFail();

        $related = Product::active()->where('category_id', $product->category_id)
            ->where('id', '!=', $product->id)->take(4)->get();

        return view('product-details', compact('product', 'related'));
    }
}
