<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $totalSales = Order::where('payment_status', 'paid')->sum('grand_total');
        $totalOrders = Order::count();
        $totalCustomers = User::where('is_admin', false)->count();
        $totalProducts = Product::count();
        $pendingOrders = Order::whereIn('status', ['placed', 'confirmed', 'processing'])->count();
        $completedOrders = Order::where('status', 'delivered')->count();

        $revenueChart = Order::selectRaw('DATE(created_at) as day, SUM(grand_total) as total')
            ->where('created_at', '>=', now()->subDays(14))
            ->groupBy('day')->orderBy('day')->get();

        $recentOrders = Order::latest()->take(8)->get();

        return view('admin.dashboard', compact(
            'totalSales', 'totalOrders', 'totalCustomers', 'totalProducts',
            'pendingOrders', 'completedOrders', 'revenueChart', 'recentOrders'
        ));
    }
}
