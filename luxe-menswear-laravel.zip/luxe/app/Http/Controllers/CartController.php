<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Coupon;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class CartController extends Controller
{
    protected function currentCart(Request $request): Cart
    {
        if ($request->user()) {
            return Cart::firstOrCreate(['user_id' => $request->user()->id]);
        }

        if (!Session::has('cart_session_id')) {
            Session::put('cart_session_id', (string) \Illuminate\Support\Str::uuid());
        }

        return Cart::firstOrCreate(['session_id' => Session::get('cart_session_id'), 'user_id' => null]);
    }

    public function index(Request $request)
    {
        $cart = $this->currentCart($request)->load('items.product.images');
        $couponCode = Session::get('coupon_code');
        $coupon = $couponCode ? Coupon::where('code', $couponCode)->first() : null;

        return view('cart', compact('cart', 'coupon'));
    }

    public function add(Request $request)
    {
        $data = $request->validate([
            'product_id' => 'required|exists:products,id',
            'size' => 'nullable|string',
            'color' => 'nullable|string',
            'quantity' => 'nullable|integer|min:1|max:20',
        ]);

        $product = Product::findOrFail($data['product_id']);
        $cart = $this->currentCart($request);
        $qty = $data['quantity'] ?? 1;

        $item = $cart->items()
            ->where('product_id', $product->id)
            ->where('size', $data['size'] ?? null)
            ->where('color', $data['color'] ?? null)
            ->first();

        if ($item) {
            $item->update(['quantity' => $item->quantity + $qty]);
        } else {
            CartItem::create([
                'cart_id' => $cart->id,
                'product_id' => $product->id,
                'size' => $data['size'] ?? null,
                'color' => $data['color'] ?? null,
                'quantity' => $qty,
                'price' => $product->final_price,
            ]);
        }

        if ($request->wantsJson()) {
            return response()->json(['success' => true, 'cart_count' => $cart->fresh()->items->sum('quantity')]);
        }

        return back()->with('success', 'Added to cart.');
    }

    public function update(Request $request, CartItem $item)
    {
        $request->validate(['quantity' => 'required|integer|min:1|max:20']);
        $item->update(['quantity' => $request->quantity]);

        if ($request->wantsJson()) {
            return response()->json(['success' => true, 'line_total' => $item->fresh()->line_total]);
        }
        return back();
    }

    public function remove(Request $request, CartItem $item)
    {
        $item->delete();
        if ($request->wantsJson()) {
            return response()->json(['success' => true]);
        }
        return back()->with('success', 'Item removed.');
    }

    public function applyCoupon(Request $request)
    {
        $request->validate(['code' => 'required|string']);
        $cart = $this->currentCart($request)->load('items');
        $coupon = Coupon::where('code', $request->code)->first();

        if (!$coupon || !$coupon->isValidFor($cart->subtotal)) {
            return back()->withErrors(['code' => 'This coupon is invalid or not applicable to your order.']);
        }

        Session::put('coupon_code', $coupon->code);
        return back()->with('success', 'Coupon applied!');
    }

    public function removeCoupon()
    {
        Session::forget('coupon_code');
        return back();
    }
}
