<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;

class ShopController extends Controller
{
    public function index(Request $request)
    {
        $query = Product::active()->with('category', 'images');

        if ($search = $request->get('q')) {
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('brand', 'like', "%{$search}%")
                  ->orWhere('short_description', 'like', "%{$search}%");
            });
        }

        if ($category = $request->get('category')) {
            $query->whereHas('category', fn ($q) => $q->where('slug', $category));
        }

        if ($request->filled('min_price')) {
            $query->where(function ($q) use ($request) {
                $q->where('discount_price', '>=', $request->min_price)
                  ->orWhere(function ($q2) use ($request) {
                      $q2->whereNull('discount_price')->where('price', '>=', $request->min_price);
                  });
            });
        }
        if ($request->filled('max_price')) {
            $query->where(function ($q) use ($request) {
                $q->where(function ($q2) use ($request) {
                    $q2->whereNotNull('discount_price')->where('discount_price', '<=', $request->max_price);
                })->orWhere(function ($q2) use ($request) {
                    $q2->whereNull('discount_price')->where('price', '<=', $request->max_price);
                });
            });
        }

        if ($size = $request->get('size')) {
            $query->whereJsonContains('sizes', $size);
        }

        if ($color = $request->get('color')) {
            $query->whereJsonContains('colors', $color);
        }

        if ($brand = $request->get('brand')) {
            $query->where('brand', $brand);
        }

        if ($rating = $request->get('rating')) {
            $query->where('rating', '>=', $rating);
        }

        switch ($request->get('sort', 'latest')) {
            case 'price_low':
                $query->orderByRaw('COALESCE(discount_price, price) asc');
                break;
            case 'price_high':
                $query->orderByRaw('COALESCE(discount_price, price) desc');
                break;
            case 'popular':
                $query->orderByDesc('sold_count');
                break;
            case 'rated':
                $query->orderByDesc('rating');
                break;
            default:
                $query->latest();
        }

        $products = $query->paginate(12)->withQueryString();
        $categories = Category::active()->orderBy('sort_order')->get();
        $brands = Product::active()->distinct()->pluck('brand');

        return view('shop', compact('products', 'categories', 'brands'));
    }
}
