<?php

namespace App\Http\Controllers;

use App\Models\Wishlist;
use App\Models\WishlistItem;
use Illuminate\Http\Request;

class WishlistController extends Controller
{
    public function index(Request $request)
    {
        $wishlist = Wishlist::firstOrCreate(['user_id' => $request->user()->id])
            ->load('items.product.images');

        return view('account.wishlist', compact('wishlist'));
    }

    public function toggle(Request $request)
    {
        $request->validate(['product_id' => 'required|exists:products,id']);
        $wishlist = Wishlist::firstOrCreate(['user_id' => $request->user()->id]);

        $existing = WishlistItem::where('wishlist_id', $wishlist->id)
            ->where('product_id', $request->product_id)->first();

        if ($existing) {
            $existing->delete();
            $status = 'removed';
        } else {
            WishlistItem::create(['wishlist_id' => $wishlist->id, 'product_id' => $request->product_id]);
            $status = 'added';
        }

        if ($request->wantsJson()) {
            return response()->json(['success' => true, 'status' => $status]);
        }

        return back();
    }
}
