<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Review;

class HomeController extends Controller
{
    public function index()
    {
        $categories = Category::active()->orderBy('sort_order')->take(6)->get();
        $featured = Product::active()->inRandomOrder()->take(8)->get();
        $newArrivals = Product::active()->where('is_new_arrival', true)->latest()->take(8)->get();
        $bestSellers = Product::active()->where('is_best_seller', true)->orderByDesc('sold_count')->take(8)->get();
        $reviews = Review::where('is_approved', true)->with('user', 'product')->latest()->take(6)->get();

        return view('home', compact('categories', 'featured', 'newArrivals', 'bestSellers', 'reviews'));
    }

    public function about()
    {
        return view('about');
    }

    public function contact()
    {
        return view('contact');
    }

    public function submitContact(\Illuminate\Http\Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'message' => 'required|string|max:2000',
        ]);

        // In production: dispatch a Mail/ContactMessage notification here.
        return back()->with('success', 'Thank you — our team will get back to you within 24 hours.');
    }
}
