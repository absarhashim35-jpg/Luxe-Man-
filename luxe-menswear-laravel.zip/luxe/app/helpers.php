<?php

if (!function_exists('image_url')) {
    /**
     * Resolve a stored image path to a browser-usable URL.
     * Seeded demo products store a full external URL; admin-uploaded
     * images store a relative path under the public storage disk.
     */
    function image_url(?string $path, string $fallback = 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600&q=80'): string
    {
        if (!$path) {
            return $fallback;
        }

        return str_starts_with($path, 'http') ? $path : asset('storage/' . $path);
    }
}
