<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use App\Models\ProductImage;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class ProductSeeder extends Seeder
{
    /**
     * category slug => [ [name, price, discount|null, images[]], ... ]
     * Image URLs are placeholders (Unsplash) — swap for real product photography in production.
     */
    public function products(): array
    {
        return [
            'suits' => [
                ['Charcoal Wool Two-Piece Suit', 549.00, 439.00, ['photo-1594938298603-c8148c4dae35', 'photo-1507679799987-c73779587ccf']],
                ['Navy Slim-Fit Tuxedo', 699.00, null, ['photo-1617137968427-85924c800a22']],
                ['Midnight Blue Three-Piece Suit', 799.00, 649.00, ['photo-1552374196-c4e7ffc6e126']],
                ['Classic Grey Pinstripe Suit', 620.00, null, ['photo-1593032465175-481ac7f401a0']],
            ],
            'blazers' => [
                ['Herringbone Wool Blazer', 349.00, 279.00, ['photo-1611312449408-fcece27cdbb7']],
                ['Linen Summer Blazer — Sand', 289.00, null, ['photo-1520975954732-35dd22299614']],
                ['Double-Breasted Navy Blazer', 399.00, null, ['photo-1617137968427-85924c800a22']],
            ],
            'formal-shirts' => [
                ['White Oxford Dress Shirt', 89.00, null, ['photo-1596755094514-f87e34085b2c']],
                ['Light Blue Slim-Fit Shirt', 79.00, 59.00, ['photo-1602810318383-e386cc2a3ccf']],
                ['Charcoal Herringbone Shirt', 95.00, null, ['photo-1598033129183-c4f50c736f10']],
                ['Striped Formal Shirt — Navy', 85.00, 69.00, ['photo-1603252109303-2751441dd157']],
            ],
            'casual-shirts' => [
                ['Linen Casual Shirt — Olive', 69.00, null, ['photo-1620012253295-c15cc3e65df4']],
                ['Denim Overshirt', 99.00, 79.00, ['photo-1591047139829-d91aecb6caea']],
                ['Flannel Check Shirt', 75.00, null, ['photo-1589992896213-6c66d1ce0eab']],
            ],
            'ties' => [
                ['Silk Navy Repp Tie', 65.00, null, ['photo-1589756823695-278bc923f962']],
                ['Burgundy Textured Silk Tie', 59.00, 45.00, ['photo-1620625515032-6ed0c1790c75']],
                ['Gold Paisley Silk Tie', 68.00, null, ['photo-1624222247344-550fb60583dc']],
            ],
            'trousers' => [
                ['Charcoal Wool Dress Trousers', 149.00, 119.00, ['photo-1473966968600-fa801b869a1a']],
                ['Slim-Fit Chino — Khaki', 89.00, null, ['photo-1473966968600-fa801b869a1a']],
                ['Tailored Navy Trousers', 139.00, null, ['photo-1473966968600-fa801b869a1a']],
            ],
            'waistcoats' => [
                ['Wool Herringbone Waistcoat', 129.00, 99.00, ['photo-1520975954732-35dd22299614']],
                ['Classic Black Formal Waistcoat', 119.00, null, ['photo-1594938298603-c8148c4dae35']],
            ],
            'formal-shoes' => [
                ['Black Oxford Leather Shoes', 249.00, 199.00, ['photo-1614252369475-531eba835eb1']],
                ['Brown Brogue Derby Shoes', 229.00, null, ['photo-1614252235316-8c857d38b5f4']],
                ['Chestnut Cap-Toe Oxfords', 259.00, null, ['photo-1533867617858-e7b97e060509']],
            ],
            'casual-shoes' => [
                ['Suede Chukka Boots — Tan', 189.00, 149.00, ['photo-1600185365483-26d7a4cc7519']],
                ['White Leather Sneakers', 159.00, null, ['photo-1549298916-b41d501d3772']],
                ['Navy Canvas Loafers', 129.00, null, ['photo-1560769629-975ec94e6a86']],
            ],
            'belts' => [
                ['Full-Grain Leather Belt — Black', 79.00, null, ['photo-1624222247344-550fb60583dc']],
                ['Reversible Leather Belt', 89.00, 69.00, ['photo-1624222247344-550fb60583dc']],
            ],
            'wallets' => [
                ['Bifold Leather Wallet — Brown', 99.00, null, ['photo-1627123424574-724758594e93']],
                ['Slim Cardholder Wallet — Black', 69.00, 55.00, ['photo-1627123424574-724758594e93']],
            ],
            'watches' => [
                ['Classic Chronograph Watch — Steel', 349.00, null, ['photo-1524805444758-089113d48a6d']],
                ['Minimalist Leather Strap Watch', 249.00, 199.00, ['photo-1524592094714-0f0654e20314']],
                ['Automatic Diver Watch — Black', 449.00, null, ['photo-1508057198894-247b23fe5ade']],
            ],
            'accessories' => [
                ['Silk Pocket Square Set', 39.00, null, ['photo-1589756823695-278bc923f962']],
                ['Leather Gloves — Black', 89.00, 69.00, ['photo-1585155770447-2f66e2a397b5']],
                ['Aviator Sunglasses', 129.00, null, ['photo-1511499767150-a48a237f0083']],
                ['Cufflinks — Gold Finish', 59.00, null, ['photo-1624222247344-550fb60583dc']],
            ],
        ];
    }

    public function run(): void
    {
        $sizes = ['S', 'M', 'L', 'XL', 'XXL'];
        $shoeSizes = ['40', '41', '42', '43', '44', '45'];
        $colors = ['Black', 'Navy', 'Charcoal', 'Grey', 'Brown', 'Tan'];

        foreach ($this->products() as $categorySlug => $items) {
            $category = Category::where('slug', $categorySlug)->first();
            if (!$category) continue;

            foreach ($items as $i => [$name, $price, $discount, $images]) {
                $isShoe = str_contains($categorySlug, 'shoes');
                $usesSizes = !in_array($categorySlug, ['belts', 'wallets', 'watches', 'accessories']);

                $product = Product::updateOrCreate(
                    ['sku' => strtoupper(Str::slug($categorySlug) . '-' . ($i + 1))],
                    [
                        'category_id' => $category->id,
                        'name' => $name,
                        'slug' => Str::slug($name) . '-' . strtolower(Str::random(4)),
                        'brand' => 'Luxe',
                        'short_description' => "Premium {$category->name} crafted from the finest materials for the modern gentleman.",
                        'description' => "The {$name} is designed with meticulous attention to detail, blending timeless tailoring with modern comfort. Made from premium materials sourced from trusted mills, this piece is built to elevate any wardrobe with understated elegance.",
                        'specifications' => [
                            'Material' => 'Premium Blend',
                            'Fit' => 'Slim Fit',
                            'Care' => 'Dry Clean Only',
                            'Origin' => 'Imported',
                        ],
                        'price' => $price,
                        'discount_price' => $discount,
                        'stock' => rand(8, 60),
                        'sizes' => $usesSizes ? ($isShoe ? $shoeSizes : $sizes) : null,
                        'colors' => array_slice($colors, 0, rand(2, 4)),
                        'rating' => round(rand(35, 50) / 10, 1),
                        'rating_count' => rand(4, 120),
                        'sold_count' => rand(0, 300),
                        'is_new_arrival' => rand(0, 1) === 1,
                        'is_best_seller' => rand(0, 3) === 1,
                        'is_active' => true,
                    ]
                );

                $product->images()->delete();
                foreach ($images as $idx => $unsplashId) {
                    ProductImage::create([
                        'product_id' => $product->id,
                        'path' => "https://images.unsplash.com/{$unsplashId}?w=900&q=80",
                        'is_primary' => $idx === 0,
                        'sort_order' => $idx,
                    ]);
                }
            }
        }
    }
}
