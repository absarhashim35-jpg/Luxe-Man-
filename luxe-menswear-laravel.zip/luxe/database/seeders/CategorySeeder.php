<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class CategorySeeder extends Seeder
{
    public static array $categories = [
        'Suits', 'Blazers', 'Formal Shirts', 'Casual Shirts', 'Ties',
        'Trousers', 'Waistcoats', 'Formal Shoes', 'Casual Shoes',
        'Belts', 'Wallets', 'Watches', 'Accessories',
    ];

    public function run(): void
    {
        foreach (self::$categories as $i => $name) {
            Category::updateOrCreate(
                ['slug' => Str::slug($name)],
                ['name' => $name, 'sort_order' => $i, 'is_active' => true]
            );
        }
    }
}
