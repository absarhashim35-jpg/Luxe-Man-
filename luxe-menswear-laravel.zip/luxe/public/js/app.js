document.addEventListener('DOMContentLoaded', function () {
  // ---- Quantity steppers on cart/product pages ----
  document.querySelectorAll('[data-qty-decrease]').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = document.querySelector(btn.dataset.qtyDecrease);
      input.value = Math.max(1, parseInt(input.value || 1) - 1);
      input.dispatchEvent(new Event('change'));
    });
  });
  document.querySelectorAll('[data-qty-increase]').forEach(btn => {
    btn.addEventListener('click', () => {
      const input = document.querySelector(btn.dataset.qtyIncrease);
      input.value = Math.min(20, parseInt(input.value || 1) + 1);
      input.dispatchEvent(new Event('change'));
    });
  });

  // ---- Product image gallery ----
  document.querySelectorAll('.thumb-list img').forEach(thumb => {
    thumb.addEventListener('click', () => {
      const main = document.querySelector('.main-product-img');
      if (main) main.src = thumb.dataset.full || thumb.src;
      document.querySelectorAll('.thumb-list img').forEach(t => t.classList.remove('active'));
      thumb.classList.add('active');
    });
  });

  // ---- Size / color swatch selection ----
  document.querySelectorAll('.size-box').forEach(el => {
    el.addEventListener('click', () => {
      el.closest('.size-options')?.querySelectorAll('.size-box').forEach(s => s.classList.remove('active'));
      el.classList.add('active');
      const input = document.querySelector('#selected_size');
      if (input) input.value = el.dataset.size;
    });
  });
  document.querySelectorAll('.swatch').forEach(el => {
    el.addEventListener('click', () => {
      el.closest('.color-options')?.querySelectorAll('.swatch').forEach(s => s.classList.remove('active'));
      el.classList.add('active');
      const input = document.querySelector('#selected_color');
      if (input) input.value = el.dataset.color;
    });
  });

  // ---- AJAX add to cart ----
  document.querySelectorAll('.ajax-add-cart').forEach(form => {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const fd = new FormData(form);
      fetch(form.action, {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' },
        body: fd,
      })
        .then(r => r.json())
        .then(data => {
          if (data.success) {
            const badge = document.querySelector('#cart-count-badge');
            if (badge) badge.textContent = data.cart_count;
            showToast('Added to cart');
          }
        })
        .catch(() => showToast('Something went wrong', true));
    });
  });

  // ---- AJAX wishlist toggle ----
  document.querySelectorAll('.ajax-wishlist').forEach(form => {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      const fd = new FormData(form);
      const btn = form.querySelector('.wishlist-btn');
      fetch(form.action, {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'application/json' },
        body: fd,
      })
        .then(r => r.json())
        .then(data => {
          if (data.success) {
            btn.classList.toggle('active', data.status === 'added');
            showToast(data.status === 'added' ? 'Added to wishlist' : 'Removed from wishlist');
          }
        });
    });
  });

  function showToast(message, isError = false) {
    let el = document.createElement('div');
    el.textContent = message;
    el.style.cssText = `position:fixed;bottom:24px;right:24px;background:${isError ? '#b00020' : '#111'};color:#fff;padding:14px 22px;border-radius:2px;z-index:9999;font-size:0.85rem;letter-spacing:0.5px;box-shadow:0 10px 24px rgba(0,0,0,.2);opacity:0;transition:opacity .3s`;
    document.body.appendChild(el);
    requestAnimationFrame(() => el.style.opacity = 1);
    setTimeout(() => { el.style.opacity = 0; setTimeout(() => el.remove(), 300); }, 2200);
  }

  // ---- Image zoom on product page ----
  const zoomImg = document.querySelector('.main-product-img[data-zoom]');
  if (zoomImg) {
    zoomImg.addEventListener('mousemove', e => {
      const rect = zoomImg.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 100;
      const y = ((e.clientY - rect.top) / rect.height) * 100;
      zoomImg.style.transformOrigin = `${x}% ${y}%`;
      zoomImg.style.transform = 'scale(1.8)';
    });
    zoomImg.addEventListener('mouseleave', () => { zoomImg.style.transform = 'scale(1)'; });
  }
});
